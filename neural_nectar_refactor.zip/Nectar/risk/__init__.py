"""Risk management policies.

This package defines simple policies for screening strategies based on
drawdown, trade count, and other metrics.  The default implementation
is a placeholder that accepts all results.  Extend
:mod:`Nectar.risk.policy` with your own checks and constraints.
"""

from .policy import evaluate_results

__all__ = ["evaluate_results"]