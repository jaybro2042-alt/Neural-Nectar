"""Basic risk evaluation placeholder.

This module provides a simple interface for evaluating the results of a
backtest or optimisation against a set of risk thresholds.  The
default implementation accepts any result.  When you define your own
policies, return ``True`` if the strategy meets the risk criteria and
``False`` otherwise.
"""

from __future__ import annotations

from typing import Any, Dict


def evaluate_results(results: Dict[str, Any], *, max_drawdown: float | None = None,
                     min_trades: int | None = None) -> bool:
    """Evaluate a result dictionary against basic risk constraints.

    Args:
        results: Arbitrary result dictionary from a backtest or optimisation.
        max_drawdown: Optional maximum allowed drawdown percentage.
        min_trades: Optional minimum number of trades required.

    Returns:
        True if the result meets all provided constraints, else False.
    """
    # These keys are common in the original implementation; they may or may
    # not be present depending on the engine used.
    dd = results.get("max_drawdown_pct")
    trades = results.get("num_trades")

    if max_drawdown is not None and dd is not None and dd > max_drawdown:
        return False
    if min_trades is not None and trades is not None and trades < min_trades:
        return False
    return True