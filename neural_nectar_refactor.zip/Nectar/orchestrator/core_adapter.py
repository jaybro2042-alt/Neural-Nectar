"""Adapter around the legacy ``core.py`` file.

The original project exposed a monolithic ``core.py`` in the root of
the repository.  To avoid breaking existing behaviour while moving
toward a more modular design, this adapter lazily imports that module
and re‑exports its public functions.  If the legacy file is not
available, functions will raise a ``RuntimeError`` explaining that the
implementation is missing.
"""

from __future__ import annotations

import importlib
import types
from typing import Any, Callable, Optional


_core_module: Optional[types.ModuleType] = None


def _load_core() -> types.ModuleType:
    """Import the legacy ``core.py`` module on demand.

    This helper attempts to import ``core`` from the top‑level package.
    If it fails, a ``RuntimeError`` is raised.  Caching is used to
    avoid repeated imports.
    """
    global _core_module
    if _core_module is not None:
        return _core_module
    try:
        _core_module = importlib.import_module("core")
        return _core_module  # type: ignore[return-value]
    except Exception as exc:
        raise RuntimeError(
            "Legacy core.py could not be imported. Ensure that core.py is "
            "present at the project root."
        ) from exc


def _delegate(name: str) -> Callable[..., Any]:
    """Return a function that delegates to the given attribute on ``core``.

    The returned wrapper imports ``core`` on first use and then looks
    up the attribute by name.  If the attribute is missing, it raises
    ``RuntimeError`` with a clear message.
    """

    def wrapper(*args: Any, **kwargs: Any) -> Any:
        mod = _load_core()
        func = getattr(mod, name, None)
        if not callable(func):
            raise RuntimeError(f"core.{name} is not implemented")
        return func(*args, **kwargs)

    return wrapper


# Delegated functions exposed by the original core.py.  If you add new
# methods to core.py that should be part of the public API, declare
# them here.

ensure_ohlcv = _delegate("ensure_ohlcv")
ensure_ohlcv_plus = _delegate("ensure_ohlcv_plus")
build_deep_csv = _delegate("build_deep_csv")
validate_csv = _delegate("validate_csv")
run_backtest_on_spec = _delegate("run_backtest_on_spec")
quick_refine = _delegate("quick_refine")
select_best = _delegate("select_best")
forward_monitor = _delegate("forward_monitor")
get_master_config = _delegate("get_master_config")
set_master_config = _delegate("set_master_config")
reload_master_config = _delegate("reload_master_config")
repair_master_config = _delegate("repair_master_config")

__all__ = [
    "ensure_ohlcv",
    "ensure_ohlcv_plus",
    "build_deep_csv",
    "validate_csv",
    "run_backtest_on_spec",
    "quick_refine",
    "select_best",
    "forward_monitor",
    "get_master_config",
    "set_master_config",
    "reload_master_config",
    "repair_master_config",
]