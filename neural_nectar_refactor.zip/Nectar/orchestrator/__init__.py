"""Orchestration layer for Nectar.

This subpackage wraps the legacy ``core.py`` module from the original
project.  Its primary purpose is to expose the same set of functions
through a namespaced API so that external callers can import
``Nectar.orchestrator`` without relying on the flat project layout.
"""

from .core_adapter import (
    ensure_ohlcv,
    ensure_ohlcv_plus,
    build_deep_csv,
    validate_csv,
    run_backtest_on_spec,
    quick_refine,
    select_best,
    forward_monitor,
    get_master_config,
    set_master_config,
    reload_master_config,
    repair_master_config,
)

__all__ = [
    "ensure_ohlcv",
    "ensure_ohlcv_plus",
    "build_deep_csv",
    "validate_csv",
    "run_backtest_on_spec",
    "quick_refine",
    "select_best",
    "forward_monitor",
    "get_master_config",
    "set_master_config",
    "reload_master_config",
    "repair_master_config",
]