"""Minimal data loading facility.

At present this module simply wraps the ``ensure_ohlcv`` function from
``Nectar.orchestrator`` and returns its result.  In the future this
function may be extended to handle multiple data providers, caching,
spread/fee models and other preprocessing steps.
"""

from __future__ import annotations

from typing import Any, Dict, Optional

from ..orchestrator import ensure_ohlcv


def fetch_ohlcv(symbol: str | None = None,
                timeframe: str | None = None,
                period: str | None = None) -> Dict[str, Any]:
    """Retrieve OHLCV data and return a summary dict.

    This function is a thin wrapper around :func:`Nectar.ensure_ohlcv`.
    It exists to provide a clear place for future extensions.
    """
    return ensure_ohlcv(symbol=symbol, timeframe=timeframe, period=period)