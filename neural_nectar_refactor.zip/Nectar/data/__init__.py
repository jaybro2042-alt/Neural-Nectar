"""Data loading helpers.

This package will eventually include functions for retrieving price
history from different sources (Yahoo Finance, CCXT, local CSVs, etc.),
preprocessing it and injecting realistic spread/fee models.  For now it
contains only a stub loader that defers to ``Nectar.ensure_ohlcv``.
"""

from .loader import fetch_ohlcv

__all__ = ["fetch_ohlcv"]