"""Backtesting engine interface and adapters.

The functions in this subpackage define a minimal interface for running
historical simulations on a strategy specification.  Currently it
forwards to the implementations in ``core.py``.  Additional engines
should implement the same signatures defined here and register
themselves in :mod:`engine_interface` so that they can be selected
dynamically at runtime.
"""

from .engine_interface import run_backtest, run_walk_forward

__all__ = ["run_backtest", "run_walk_forward"]