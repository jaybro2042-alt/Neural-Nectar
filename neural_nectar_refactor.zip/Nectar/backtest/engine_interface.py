"""Backtesting engine interface.

This module defines a simple API for backtesting and walk‑forward
analysis.  By default it wraps the corresponding functions in
``Nectar.orchestrator.core_adapter``.  If you implement additional
engines (e.g. Backtrader, PyBroker), register them in the ``_ENGINES``
mapping below and they will be available for selection.
"""

from __future__ import annotations

from typing import Any, Callable, Dict, Optional

from ..orchestrator.core_adapter import run_backtest_on_spec, quick_refine, select_best, forward_monitor

# Type alias for engine functions
BacktestFn = Callable[[str], Any]
WalkForwardFn = Callable[[str], Any]


class Engine:
    """Encapsulate a pair of functions for backtest and walk‑forward.

    Engines can be registered in the ``_ENGINES`` mapping below.  Each
    engine exposes a ``run_backtest`` function that takes the path to a
    strategy spec and returns arbitrary results (e.g. a metrics dict),
    and optionally a ``run_walk_forward`` function.
    """

    def __init__(self, backtest_fn: BacktestFn, walk_forward_fn: Optional[WalkForwardFn] = None) -> None:
        self.backtest_fn = backtest_fn
        self.walk_forward_fn = walk_forward_fn

    def run_backtest(self, spec_path: str) -> Any:
        return self.backtest_fn(spec_path)

    def run_walk_forward(self, spec_path: str) -> Any:
        if self.walk_forward_fn is None:
            raise NotImplementedError("walk-forward is not implemented for this engine")
        return self.walk_forward_fn(spec_path)


# Register built‑in engine that wraps the legacy core functions
_ENGINES: Dict[str, Engine] = {
    "core": Engine(backtest_fn=run_backtest_on_spec, walk_forward_fn=forward_monitor),
}


def get_engine(name: str = "core") -> Engine:
    """Retrieve a backtesting engine by name.

    If the requested engine is not registered, a ``KeyError`` is raised.
    """
    return _ENGINES[name]


def run_backtest(spec_path: str, engine: str = "core") -> Any:
    """Run a backtest on the given strategy specification using the selected engine."""
    eng = get_engine(engine)
    return eng.run_backtest(spec_path)


def run_walk_forward(spec_path: str, engine: str = "core") -> Any:
    """Run a walk‑forward analysis on the given strategy specification."""
    eng = get_engine(engine)
    return eng.run_walk_forward(spec_path)