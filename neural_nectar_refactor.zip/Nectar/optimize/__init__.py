"""Optimisation routines.

This package defines the hooks for tuning strategy parameters.  The
default implementation is a stub that simply returns the original
specification without changes.  When adding new optimisers (e.g.
grid search, Bayesian), implement a function with the same signature
as :func:`run_optimization` and register it here.
"""

from .objective import run_optimization

__all__ = ["run_optimization"]