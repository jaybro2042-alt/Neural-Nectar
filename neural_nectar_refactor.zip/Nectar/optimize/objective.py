"""Parameter optimisation stubs.

At this stage optimisation is not implemented.  The function
``run_optimization`` simply returns the input specification path and
produces a no‑op result.  Extend this module with your preferred
optimisation library (e.g. Optuna, Nevergrad) and expose a unified
interface.
"""

from __future__ import annotations

from typing import Any, Dict


def run_optimization(spec_path: str, *, engine: str = "core", budget: int = 10) -> Dict[str, Any]:
    """Optimise parameters for the given strategy specification.

    Args:
        spec_path: Path to the JSON strategy specification.
        engine: Name of the backtesting engine to use.
        budget: Number of trials or evaluations (ignored for now).

    Returns:
        A dictionary containing the best parameters and any metrics
        measured during optimisation.  Currently returns an empty
        result and echoes the input path.
    """
    return {
        "spec_path": spec_path,
        "best_params": {},
        "engine": engine,
        "budget": budget,
        "note": "optimisation not yet implemented"
    }