"""Utilities for loading and validating strategy specifications.

The strategy domain‑specific language (DSL) allows a strategy to be
expressed in a declarative JSON format.  This subpackage contains a
sample schema and a loader function that validates input files.
"""

from .loader import load_spec, validate_spec

__all__ = ["load_spec", "validate_spec"]