"""Load and validate strategy specifications defined in JSON.

At present this loader performs only minimal validation against a
bundled JSON schema.  If the optional ``jsonschema`` library is
available it will be used to perform full schema validation.  Otherwise
the loader will still parse the file and return the contents as a
dictionary.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict

try:
    import jsonschema  # type: ignore
except Exception:
    jsonschema = None  # type: ignore

SCHEMA_PATH = Path(__file__).with_name("schema.json")


def load_spec(path: str | Path) -> Dict[str, Any]:
    """Read a JSON strategy specification from ``path``.

    If the file cannot be parsed, a ``ValueError`` is raised.  When
    ``jsonschema`` is installed, the specification is validated against
    the bundled schema.  Validation errors will raise ``ValueError``.
    """
    p = Path(path)
    raw = p.read_text(encoding="utf-8")
    try:
        spec = json.loads(raw)
    except Exception as exc:
        raise ValueError(f"Failed to parse JSON from {p}: {exc}") from exc

    # optional schema validation
    if jsonschema is not None:
        try:
            schema = json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))
            jsonschema.validate(instance=spec, schema=schema)
        except jsonschema.ValidationError as exc:  # type: ignore[attr-defined]
            raise ValueError(f"Specification does not conform to schema: {exc}") from exc
    return spec  # type: ignore[return-value]


def validate_spec(spec: Dict[str, Any]) -> bool:
    """Validate a spec dict against the bundled schema, if possible.

    Returns ``True`` if the specification is valid or if jsonschema is
    unavailable.  Otherwise raises ``ValueError`` on validation failure.
    """
    if jsonschema is None:
        return True
    schema = json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))
    jsonschema.validate(instance=spec, schema=schema)  # type: ignore[attr-defined]
    return True