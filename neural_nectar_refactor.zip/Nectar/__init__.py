"""Top‑level package for the core trading infrastructure.

The :mod:`Nectar` package provides a clean separation between the
foundation of a trading system (data loading, backtesting, optimisation,
risk management, etc.) and the higher‑level conversational agent that
interacts with a user.  Most modules here are thin wrappers around the
original implementation from ``core.py`` and related scripts.  Over
time these stubs can be expanded to incorporate more advanced
functionality without disrupting the public API.
"""

# Expose commonly used names at the package level.  These import the
# underlying implementations from the orchestrator layer.  See
# :mod:`Nectar.orchestrator.core_adapter` for details.

from .orchestrator.core_adapter import (
    ensure_ohlcv,
    ensure_ohlcv_plus,
    build_deep_csv,
    validate_csv,
    run_backtest_on_spec,
    quick_refine,
    select_best,
    forward_monitor,
    get_master_config,
    set_master_config,
    reload_master_config,
    repair_master_config,
)

__all__ = [
    "ensure_ohlcv",
    "ensure_ohlcv_plus",
    "build_deep_csv",
    "validate_csv",
    "run_backtest_on_spec",
    "quick_refine",
    "select_best",
    "forward_monitor",
    "get_master_config",
    "set_master_config",
    "reload_master_config",
    "repair_master_config",
]