# Neural Nectar (Refactored)

This repository provides a clean, extensible foundation for building and
evolving quantitative trading agents.  It separates the core trading
infrastructure (``Nectar``) from the higher‑level conversational agent
(``NeuralAgent``) that interacts with users.  The goal of this refactor
is to supply a solid base that can be extended without breaking existing
functionality.  All new features should be layered on top of the
foundation rather than patched into it.

## Directory Overview

```
neural_nectar_refactor/
 ├── Nectar/                # Foundational trading and backtesting logic
 │   ├── orchestrator/      # Orchestration and configuration management
 │   ├── strategy_dsl/      # Strategy definitions and schema loader
 │   ├── data/              # Data loading and preprocessing
 │   ├── backtest/          # Engine interface and runner adapters
 │   ├── optimize/          # Parameter search and walk‑forward stubs
 │   ├── risk/              # Risk management policies and guards
 │   └── export/            # Exporters (e.g., Pine Script)
 ├── NeuralAgent/           # Chat‑first agent built on top of Nectar
 │   ├── chat_agent.py      # Simple natural language router
 │   ├── console_agent.py   # Text console fallback for local use
 │   └── ui_dashboard.py    # Streamlit dashboard (optional)
 └── README.md              # This file
```

### Nectar

The ``Nectar`` package encapsulates everything needed to fetch data,
interpret a strategy definition, run backtests, perform parameter
optimisation, enforce risk limits, and export runnable scripts.  In this
initial commit most of these modules are simple wrappers around the
existing ``core.py`` and other helper scripts from the original
repository.  As the project evolves, new functionality should be added
here while preserving the interface exposed to callers.

### NeuralAgent

The ``NeuralAgent`` package contains user‑facing agents.  These
components provide natural language or command‑line interfaces and
delegate any trading or file operations to the ``Nectar`` layer.  The
default chat agent uses a simple heuristic router as a fallback when no
OpenAI API key is available.

## Migrated Files

The following files from the original project remain available via
imports or wrappers:

- ``core.py`` → wrapped by ``Nectar/orchestrator/core_adapter.py``
- ``api_agent.py`` → exposed as ``NeuralAgent/chat_agent.py``
- ``agent_workspace.py`` → exposed as ``NeuralAgent/console_agent.py``
- ``dashboard_ui.py`` → exposed as ``NeuralAgent/ui_dashboard.py``
- ``audcad_wft_backtrader.py`` → available through ``Nectar/backtest``

Future work may involve relocating these originals into the Nectar
hierarchy.  Until then, adapters import the existing modules and
re‑export their public functions.
