"""Console agent for local filesystem and trading operations.

This module provides a simple command‑line interface that combines
trading functions from ``Nectar`` with basic file management.  It is
adapted from ``agent_workspace.py`` in the original project and
restructured into a class for easier extension.  The console agent
operates entirely offline; it does not use any LLMs.
"""

from __future__ import annotations

import os
import re
import json
import shutil
import subprocess
import traceback
from pathlib import Path
from typing import Optional

from ..Nectar import (
    ensure_ohlcv,
    run_backtest_on_spec,
    quick_refine,
    select_best,
)


class ConsoleAgent:
    """Interactive command‑line agent for local tasks and trading."""

    def __init__(self, root: str | Path | None = None) -> None:
        self.root = Path(root or Path.cwd()).resolve()

    # Filesystem helpers
    def ls(self, path: str) -> str:
        p = Path(path or ".")
        if not p.exists():
            return f"[ls] not found: {p}"
        rows = []
        for entry in sorted(p.iterdir()):
            typ = "<DIR>" if entry.is_dir() else f"{entry.stat().st_size}B"
            rows.append(f"{typ:>8}  {entry.name}")
        return "\n".join(rows) or "(empty)"

    def read(self, path: str, max_bytes: int = 200_000) -> str:
        p = Path(path)
        if not p.exists() or not p.is_file():
            return f"[read] file not found: {p}"
        data = p.read_bytes()
        if len(data) > max_bytes:
            head = data[:max_bytes].decode(errors="replace")
            return f"[read] too large ({len(data)} bytes). Showing first {max_bytes} bytes:\n{head}"
        return data.decode(errors="replace")

    def write(self, path: str, content: str, mkdirs: bool = True) -> str:
        p = Path(path)
        if mkdirs:
            p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding="utf-8")
        return f"[write] ok → {p}"

    def append(self, path: str, content: str, mkdirs: bool = True) -> str:
        p = Path(path)
        if mkdirs:
            p.parent.mkdir(parents=True, exist_ok=True)
        with p.open("a", encoding="utf-8") as f:
            f.write(content)
        return f"[append] ok → {p}"

    def copy(self, src: str, dst: str) -> str:
        s, d = Path(src), Path(dst)
        d.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(s, d)
        return f"[copy] {s} → {d}"

    def move(self, src: str, dst: str) -> str:
        s, d = Path(src), Path(dst)
        d.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(s), str(d))
        return f"[move] {s} → {d}"

    def rm(self, path: str) -> str:
        p = Path(path)
        if p.is_dir():
            shutil.rmtree(p)
            return f"[rm] dir removed → {p}"
        if p.exists():
            p.unlink()
            return f"[rm] file removed → {p}"
        return f"[rm] not found: {p}"

    def mkdir(self, path: str) -> str:
        p = Path(path)
        p.mkdir(parents=True, exist_ok=True)
        return f"[mkdir] ok → {p}"

    def shell(self, cmd: str) -> str:
        if not cmd.strip():
            return "Usage: shell <command>"
        out = subprocess.run(cmd, shell=True, capture_output=True, text=True)
        return (out.stdout or "") + (out.stderr or "")

    # Trading commands
    def do_backtest(self, spec_path: str) -> str:
        try:
            out = run_backtest_on_spec(spec_path)
            return json.dumps(out, indent=2) if out is not None else "[backtest done]"
        except Exception:
            traceback.print_exc()
            return "[error] backtest failed"

    def do_refine(self, spec_path: str) -> str:
        try:
            out = quick_refine(spec_path)
            return json.dumps(out, indent=2) if out is not None else "[refine done]"
        except Exception:
            traceback.print_exc()
            return "[error] refine failed"

    def do_select_best(self, reports_path: str) -> str:
        try:
            out = select_best(reports_path)
            return json.dumps(out, indent=2) if out is not None else "[select_best done]"
        except Exception:
            traceback.print_exc()
            return "[error] select_best failed"

    def do_ohlcv(self, symbol: str, timeframe: str, period: str) -> str:
        try:
            out = ensure_ohlcv(symbol, timeframe, period)
            return json.dumps(out, indent=2) if out is not None else "[ohlcv done]"
        except Exception:
            traceback.print_exc()
            return "[error] failed to fetch OHLCV"

    def run_cmd(self, line: str) -> str:
        parts = line.strip().split()
        if not parts:
            return ""
        cmd, args = parts[0], parts[1:]

        try:
            if cmd in ("quit", "exit"):
                raise KeyboardInterrupt
            if cmd in ("ls", "list"):
                if not args:
                    return "Usage: ls <path>"
                return self.ls(args[0])
            if cmd == "read":
                if not args:
                    return "Usage: read <path>"
                return self.read(args[0])
            if cmd == "write":
                # syntax: write <path> :: <content>
                rest = line.partition("write")[2].strip()
                parts2 = rest.split("::", 1)
                if len(parts2) == 2:
                    return self.write(parts2[0].strip(), parts2[1])
                return "Usage: write <path> :: <content>"
            if cmd == "append":
                rest = line.partition("append")[2].strip()
                parts2 = rest.split("::", 1)
                if len(parts2) == 2:
                    return self.append(parts2[0].strip(), parts2[1])
                return "Usage: append <path> :: <content>"
            if cmd == "copy":
                rest = line.partition("copy")[2].strip()
                parts2 = re.split(r"\s*->\s*", rest, 1)
                if len(parts2) == 2:
                    return self.copy(parts2[0], parts2[1])
                return "Usage: copy <src> -> <dst>"
            if cmd == "move":
                rest = line.partition("move")[2].strip()
                parts2 = re.split(r"\s*->\s*", rest, 1)
                if len(parts2) == 2:
                    return self.move(parts2[0], parts2[1])
                return "Usage: move <src> -> <dst>"
            if cmd == "rm":
                if not args:
                    return "Usage: rm <path>"
                return self.rm(args[0])
            if cmd == "mkdir":
                if not args:
                    return "Usage: mkdir <path>"
                return self.mkdir(args[0])
            if cmd == "shell":
                shell_line = line.partition("shell")[2].strip()
                return self.shell(shell_line)
            if cmd == "backtest":
                if not args:
                    return "Usage: backtest <spec.json>"
                return self.do_backtest(args[0])
            if cmd == "refine":
                if not args:
                    return "Usage: refine <spec.json>"
                return self.do_refine(args[0])
            if cmd == "select_best":
                if not args:
                    return "Usage: select_best <reports_dir>"
                return self.do_select_best(args[0])
            if cmd == "ohlcv":
                if len(args) < 3:
                    return "Usage: ohlcv <symbol> <timeframe> <period>"
                return self.do_ohlcv(args[0], args[1], args[2])
        except Exception as e:
            traceback.print_exc()
            return f"[error] {e}"
        return f"unknown command: {cmd}"

    def repl(self) -> None:
        """Run an interactive command loop until KeyboardInterrupt."""
        print("NeuralAgent Console. Type commands; 'quit' to exit.")
        while True:
            try:
                line = input("» ").strip()
            except EOFError:
                break
            if not line:
                continue
            try:
                out = self.run_cmd(line)
                if out is not None:
                    print(out)
            except KeyboardInterrupt:
                print("bye")
                break


__all__ = ["ConsoleAgent"]