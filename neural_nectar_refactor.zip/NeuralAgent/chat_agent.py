"""Natural language chat agent.

This module defines a simple conversational agent that interprets
plaintext requests and delegates to the appropriate functions in the
underlying ``Nectar`` package.  It can run entirely offline using
heuristics or make use of an OpenAI model when an API key is present.

The implementation here is adapted from the original ``api_agent.py``
and refactored into a class to aid extensibility.  Only a subset of
commands (``ohlcv``, ``backtest``, ``refine``, ``select_best``) are
supported in the offline router.  When an API key is available the
agent can call the OpenAI API to generate responses.
"""

from __future__ import annotations

import os
import re
import json
import traceback
from pathlib import Path
from typing import Optional

# Import from the sibling package using a relative import.  The
# ``Nectar`` namespace lives under ``neural_nectar_refactor.Nectar``.  Using
# relative imports here avoids polluting the global module namespace and
# supports packaging and testing the project without special path hacks.
from ..Nectar import (
    ensure_ohlcv,
    run_backtest_on_spec,
    quick_refine,
    select_best,
)


class ChatAgent:
    """A chat‑based trading assistant.

    The agent supports both offline (heuristic) and online (LLM) modes.
    In offline mode it recognises simple keywords and invokes the
    corresponding functions from ``Nectar``.  In online mode it sends
    the entire conversation to the OpenAI API for a response.  Model
    selection and API configuration are controlled via environment
    variables ``OPENAI_API_KEY`` and ``OPENAI_MODEL``.
    """

    def __init__(self) -> None:
        # Determine if we can use OpenAI
        self.use_llm = False
        self._llm_client = None
        key = os.getenv("OPENAI_API_KEY", "")
        if key:
            try:
                import openai  # type: ignore
                self._llm_client = openai.OpenAI(api_key=key)
                self.use_llm = True
            except Exception:
                # Failed to initialise the client; fall back to offline
                self.use_llm = False

    def _local_router(self, text: str) -> str:
        """Heuristic parser for offline operation."""
        t = (text or "").strip()
        low = t.lower()

        # ohlcv command: "ohlcv AUDCAD 5m 30d"
        if "ohlcv" in low:
            parts = low.split()
            if len(parts) >= 4:
                sym, tf, period = parts[-3], parts[-2], parts[-1]
                try:
                    result = ensure_ohlcv(sym, tf, period)
                    return json.dumps(result, indent=2)
                except Exception:
                    traceback.print_exc()
                    return "[error] failed to fetch OHLCV"

        # backtest command: expects a JSON filename
        if "backtest" in low and ".json" in low:
            m = re.findall(r'([\w./\\-]+\.json)', t)
            if m:
                try:
                    res = run_backtest_on_spec(m[-1])  # type: ignore
                    return json.dumps(res, indent=2)
                except Exception:
                    traceback.print_exc()
                    return "[error] backtest failed"

        # refine command
        if "refine" in low and ".json" in low:
            m = re.findall(r'([\w./\\-]+\.json)', t)
            if m:
                try:
                    res = quick_refine(m[-1])  # type: ignore
                    return json.dumps(res, indent=2)
                except Exception:
                    traceback.print_exc()
                    return "[error] refine failed"

        # select_best command
        if "select_best" in low:
            parts = t.split()
            if parts:
                last = parts[-1]
                try:
                    res = select_best(last)  # type: ignore
                    return json.dumps(res, indent=2)
                except Exception:
                    traceback.print_exc()
                    return "[error] select_best failed"

        # help
        if low in ("!!tools", "tools", "help"):
            return (
                "I can understand:\n"
                "  • ohlcv   \n"
                "  • backtest \n"
                "  • refine \n"
                "  • select_best \n"
                "You can type English like: 'run a backtest on strategies/demo_ema_rsi.json'"
            )

        return (
            "I'm listening. Try: 'run a backtest on strategies/demo_ema_rsi.json', "
            "'get ohlcv for AUDCAD 5m 30d', or 'refine strategies/base_ema_rsi.json'."
        )

    def handle_message(self, message: str) -> str:
        """Process a single user message and return a response."""
        if not message:
            return ""
        # Offline mode: use heuristic router
        if not self.use_llm:
            return self._local_router(message)
        # Online mode: call LLM
        try:
            model = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
            resp = self._llm_client.chat.completions.create(
                model=model,
                messages=[
                    {
                        "role": "system",
                        "content": (
                            "You are a helpful trading assistant. Keep answers concise. "
                            "If the user mentions backtest, refine, ohlcv, or select_best "
                            "with a JSON path or symbol/timeframe/period, clearly echo the suggested command and result."
                        ),
                    },
                    {"role": "user", "content": message},
                ],
            )
            return resp.choices[0].message.content or ""
        except Exception as e:
            # Fallback to offline router on error
            print(f"[online error] {e}. Falling back to local.")
            return self._local_router(message)

    def repl(self) -> None:
        """Run a simple interactive loop in the terminal."""
        print("NeuralAgent Chat. Type naturally. Commands still work.")
        print("Type 'quit' to exit.")
        while True:
            try:
                msg = input("you> ").strip()
            except EOFError:
                break
            if not msg:
                continue
            if msg.lower() in ("quit", "exit", "bye"):
                print("bye")
                break
            out = self.handle_message(msg)
            print(out)


__all__ = ["ChatAgent"]