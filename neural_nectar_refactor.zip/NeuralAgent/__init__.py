"""Entry point for chat‑based trading agents.

The :mod:`NeuralAgent` package exposes high‑level conversational agents
that wrap the foundational capabilities in :mod:`Nectar`.  Agents are
responsible for interpreting user input, routing requests to the proper
tools in ``Nectar`` and returning human‑readable responses.  This
package currently re‑exports the chat and console agents defined in
their respective modules.
"""

from .chat_agent import ChatAgent
from .console_agent import ConsoleAgent

__all__ = ["ChatAgent", "ConsoleAgent"]