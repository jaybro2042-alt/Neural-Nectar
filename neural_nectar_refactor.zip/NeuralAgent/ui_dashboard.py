"""Wrapper around the legacy Streamlit dashboard.

The original repository provided a small Streamlit application in
``dashboard_ui.py``.  To avoid breaking existing users while moving
toward the refactored layout, this module simply attempts to import
``dashboard_ui`` from the project root and run it.  If the import
fails, a clear error message is printed.
"""

from __future__ import annotations

import importlib


def run_dashboard() -> None:
    """Run the Streamlit dashboard if available."""
    try:
        mod = importlib.import_module("dashboard_ui")
    except Exception as exc:
        raise RuntimeError(
            "dashboard_ui.py not found. The Streamlit dashboard cannot be launched."
        ) from exc
    if hasattr(mod, "__file__"):
        # Execute the module as a script; Streamlit expects a script file
        import subprocess
        subprocess.run(["streamlit", "run", mod.__file__], check=False)
    else:
        raise RuntimeError("dashboard_ui module is invalid; missing __file__ attribute")


__all__ = ["run_dashboard"]