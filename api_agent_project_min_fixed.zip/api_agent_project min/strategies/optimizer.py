﻿import json, pathlib, itertools, time
from datetime import datetime
from main_agent_entry import pipeline_run
ROOT=pathlib.Path('.')
STR_DIR=ROOT/'strategies'
REPORTS=ROOT/'reports'
REPORTS.mkdir(exist_ok=True)
strategy_files=['default_ema_rsi.json','scary_omni.json','scary_osprey.json','scary_roughdeluxe.json','scary_skeleton.json']
# grids
ema_fast_list=[8,10,12,15]
ema_slow_list=[20,30,40]
rsi_lo_list=[30,40]
rsi_hi_list=[60,70]
# store overall results
all_results=[]
for sf in strategy_files:
    fp=STR_DIR/sf
    if not fp.exists():
        print('missing',sf); continue
    cfg=json.loads(fp.read_text())
    cfg['enabled']=True
    sym=cfg.get('symbol','AUDCAD')
    tf=cfg.get('timeframe','5m')
    period=cfg.get('period','30d')
    orig_ind=cfg.get('indicators',{})
    orig_return=None
    # try run original once
    try:
        s0=pipeline_run(None, symbol=sym, timeframe=tf, period=period, ema_fast=orig_ind.get('ema_fast',10), ema_slow=orig_ind.get('ema_slow',20), rsi_length=orig_ind.get('rsi_period',14), rsi_entry_low=30, rsi_entry_high=70)
        orig_return = s0['metrics'].get('total_return_pct')
    except Exception as e:
        orig_return = None
    best=None
    for ef, es, rlo, rhi in itertools.product(ema_fast_list, ema_slow_list, rsi_lo_list, rsi_hi_list):
        if ef>=es: continue
        try:
            s=pipeline_run(None, symbol=sym, timeframe=tf, period=period, ema_fast=ef, ema_slow=es, rsi_length=14, rsi_entry_low=rlo, rsi_entry_high=rhi)
        except Exception as e:
            print('err',sf,ef,es,rlo,rhi,e)
            continue
        metrics=s['metrics']
        # ranking key: total_return, then -max_drawdown, then win_rate
        tr=metrics.get('total_return_pct',-9999)
        dd=metrics.get('max_drawdown_pct',9999)
        wr=metrics.get('win_rate_pct',0)
        key=(tr, -dd, wr)
        if best is None or key>best['key']:
            best={'key':key,'summary':s,'params':(ef,es,14,rlo,rhi)}
        print(f"{sf} try ef{ef} es{es} r{rlo}-{rhi} => tr={tr} dd={dd} wr={wr}")
        time.sleep(0.3)
    if best:
        best_summary=best['summary']
        all_results.append({'file':sf,'best':best_summary,'params':best['params'],'orig_return':orig_return})
        # overwrite strategy indicators with best params
        cfg['indicators']={'ema_fast':best['params'][0],'ema_slow':best['params'][1],'rsi_period':best['params'][2]}
        # also set entry/exit RSI thresholds if present
        entry=cfg.get('entry')
        if isinstance(entry,dict) and 'long' in entry:
            cfg['entry']['long']=f"close > ema_fast and ema_fast > ema_slow and rsi >= {best['params'][3]} and rsi <= {best['params'][4]}"
        cfg['last_optimized']=datetime.utcnow().isoformat()
        fp.write_text(json.dumps(cfg,indent=2))
        print('updated',sf,'with',cfg['indicators'])
    else:
        print('no best found for',sf)
# write overall report
outf=REPORTS/f"optimizer_summary_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.json"
outf.write_text(json.dumps(all_results,indent=2))
print('done')
