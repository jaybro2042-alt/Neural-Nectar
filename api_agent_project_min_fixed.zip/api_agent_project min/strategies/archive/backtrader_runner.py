# backtrader_runner.py
# Drop this into: control_center/backtrader_bridge_min/runner.py
# Requires: pip install backtrader
# Usage:
#   from backtrader_bridge_min.runner import run_backtest
#   metrics = run_backtest(strategy_json, csv_path="data/EURUSD_1m.csv")
#
# Expects CSV with columns: datetime,open,high,low,close,volume
# datetime in ISO or %Y-%m-%d %H:%M:%S; adjust dtformat if needed.

import re
import math
import datetime as _dt
from typing import Dict, Any, Optional

import backtrader as bt

# ---- Data feed ----

class GenericOHLCV(bt.feeds.GenericCSVData):
    params = (
        ('dtformat', '%Y-%m-%d %H:%M:%S'),
        ('datetime', 0),
        ('open', 1),
        ('high', 2),
        ('low', 3),
        ('close', 4),
        ('volume', 5),
        ('openinterest', -1),
    )

# ---- Strategy builder ----

class JSONStrategy(bt.Strategy):
    params = dict(spec=None)  # spec is the strategy_json dict

    def __init__(self):
        self.order = None
        spec = self.p.spec or {}
        params = spec.get('params', {})
        self.mode = self._infer_mode(params, spec)

        # Indicators (create if mentioned)
        self.ema = None
        if 'ema' in params:
            self.ema = bt.ind.EMA(self.data.close, period=int(params['ema']))
        if 'ema_fast' in params and 'ema_slow' in params:
            self.ema_fast = bt.ind.EMA(self.data.close, period=int(params['ema_fast']))
            self.ema_slow = bt.ind.EMA(self.data.close, period=int(params['ema_slow']))

        self.rsi = None
        if 'rsi' in params:
            self.rsi = bt.ind.RSI(period=int(params['rsi']))

        self.bb = None
        if 'bb_period' in params:
            self.bb = bt.ind.BollingerBands(period=int(params['bb_period']),
                                            devfactor=float(params.get('bb_std', 2)))

        self.dc = None
        if 'donchian' in params:
            self.dc = bt.ind.DonchianChannel(period=int(params['donchian']))

        self.atr = bt.ind.ATR(period=int(params.get('atr', 14)))

        # Risk sizing (very simple ATR-based position sizing)
        self.risk_pct = float(spec.get('risk', {}).get('risk_pct', 0.5)) / 100.0  # convert % to fraction
        self.atr_mult = _parse_atr_mult(spec.get('risk', {}).get('stop', '2*ATR(14)'))
        self.value_per_point = 1.0  # placeholder; adapt per instrument if needed

    def _infer_mode(self, params, spec):
        s = (spec.get('name','') + ' ' + spec.get('entry','')).lower()
        if 'donchian' in params or 'breakout' in s:
            return 'breakout'
        if 'bb_period' in params or 'boll' in s or 'mean-rev' in s or 'revert' in s:
            return 'meanrev'
        if 'ema' in params and 'rsi' in params:
            return 'momo'
        return 'momo'

    def next(self):
        if self.order:
            return

        # flat state
        if not self.position:
            if self._long_signal():
                size = self._calc_size()
                self.order = self.buy(size=size)
                self._place_stops(target='long')
            elif self._short_signal():
                size = self._calc_size()
                self.order = self.sell(size=size)
                self._place_stops(target='short')
        else:
            # exits on opposite signal
            if self.position.size > 0 and self._short_signal():
                self.order = self.close()
            elif self.position.size < 0 and self._long_signal():
                self.order = self.close()

    # ---- Signals ----
    def _long_signal(self):
        if self.mode == 'momo':
            cond1 = self.ema is not None and self.data.close[0] > self.ema[0]
            cond2 = self.rsi is None or self.rsi[0] > 55
            return cond1 and cond2
        if self.mode == 'meanrev':
            below = self.bb and self.data.close[0] < self.bb.lines.bot[0]
            r = (self.rsi is None) or (self.rsi[0] < 30)
            return below and r
        if self.mode == 'breakout':
            return self.dc and self.data.close[0] > self.dc.lines.dch[0]
        return False

    def _short_signal(self):
        if self.mode == 'momo':
            cond1 = self.ema is not None and self.data.close[0] < self.ema[0]
            cond2 = self.rsi is None or self.rsi[0] < 45
            return cond1 and cond2
        if self.mode == 'meanrev':
            above = self.bb and self.data.close[0] > self.bb.lines.top[0]
            r = (self.rsi is None) or (self.rsi[0] > 70)
            return above and r
        if self.mode == 'breakout':
            return self.dc and self.data.close[0] < self.dc.lines.dcl[0]
        return False

    def _calc_size(self):
        # position size: risk_pct of equity over ATR-based stop distance
        cash = self.broker.get_cash()
        risk_dollars = max(1e-8, cash * self.risk_pct)
        stop_dist = max(1e-8, self.atr[0] * self.atr_mult)
        size = max(1, int(risk_dollars / (stop_dist * self.value_per_point)))
        return size

    def _place_stops(self, target='long'):
        # This is a lightweight protective stop; TP handled by reversal or fixed R taken implicitly.
        # For simplicity we avoid bracket orders (some brokers/backends vary).
        pass

def _parse_atr_mult(expr: str) -> float:
    # parse things like "2*ATR(14)" -> 2.0
    m = re.search(r'([0-9]*\.?[0-9]+)\s*\*\s*ATR', str(expr).upper())
    if m:
        try:
            return float(m.group(1))
        except Exception:
            return 2.0
    return 2.0

# ---- Runner ----

def run_backtest(strategy_json: Dict[str, Any],
                 csv_path: Optional[str] = None,
                 cash: float = 100000.0,
                 commission: float = 0.0002,
                 timeframe: Optional[str] = None) -> Dict[str, float]:
    """
    Run a Backtrader backtest for a given strategy_json.
    Returns metrics: {"sharpe": float, "roi_pct": float, "max_dd_pct": float, "trades": int}
    """
    cerebro = bt.Cerebro()
    cerebro.broker.setcash(cash)
    cerebro.broker.setcommission(commission=commission)

    # Data
    if csv_path is None:
        # Try to infer from symbol/timeframe
        sym = (strategy_json.get('universe', ['SYMBOL'])[0]).replace('/','')
        tf = timeframe or strategy_json.get('timeframe', '1m')
        csv_path = f"data/{sym}_{tf}.csv"
    data = GenericOHLCV(dataname=csv_path)
    cerebro.adddata(data)

    # Strategy
    cerebro.addstrategy(JSONStrategy, spec=strategy_json)

    # Analyzers
    cerebro.addanalyzer(bt.analyzers.DrawDown, _name='dd')
    cerebro.addanalyzer(bt.analyzers.TradeAnalyzer, _name='trades')
    try:
        cerebro.addanalyzer(bt.analyzers.SharpeRatio, _name='sharpe', timeframe=bt.TimeFrame.Days, annualize=True)
    except Exception:
        pass

    results = cerebro.run()
    strat = results[0]

    # Metrics
    portvalue = cerebro.broker.getvalue()
    roi_pct = (portvalue / cash - 1.0) * 100.0

    dd = strat.analyzers.dd.get_analysis()
    max_dd_pct = float(dd.get('max', {}).get('drawdown', 0.0))

    trades = strat.analyzers.trades.get_analysis()
    total_closed = int(getattr(trades.total, 'closed', 0)) if hasattr(trades, 'total') else 0

    sharpe = None
    if hasattr(strat.analyzers, 'sharpe'):
        try:
            sharpe = strat.analyzers.sharpe.get_analysis().get('sharperatio', None)
            if sharpe is None:
                # fallback: 0 if not enough variance or periods
                sharpe = 0.0
        except Exception:
            sharpe = 0.0
    else:
        sharpe = 0.0

    return {"sharpe": float(sharpe or 0.0),
            "roi_pct": float(round(roi_pct, 4)),
            "max_dd_pct": float(round(max_dd_pct, 4)),
            "trades": int(total_closed)}
