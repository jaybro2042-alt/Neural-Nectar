"""Backtrader strategy runner for AUDCAD 5m — Scary Skeleton variant.

Requirements: pip install backtrader yfinance pandas numpy matplotlib

This script does the following:
- Attempts to load data/data_audcad_5m.csv. If not found, will download via yfinance for AUDCAD=X (5m, last 60d) and save it.
- Runs Backtrader with a risk-controlled ATR-based stop strategy tuned to target high ROI/day with <=1% max drawdown (configurable).

import os
import math
import datetime as dt
