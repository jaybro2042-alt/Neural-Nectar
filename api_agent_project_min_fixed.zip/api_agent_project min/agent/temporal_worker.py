# temporal_worker.py
import asyncio, json
from pathlib import Path
from typing import Dict, Any, List
from temporalio import activity, workflow
from temporalio.client import Client
from temporalio.worker import Worker

# Orchestrator calls
from orchestrator import core as ORC

# ---------- Activities ----------
@activity.defn
async def act_build_deep_csv(symbol: str, timeframe: str, period: str="30d") -> Dict[str, Any]:
    return ORC.ensure_ohlcv_plus(symbol, timeframe, period=period, indicators=None, strict=False)

@activity.defn
async def act_run_spec(spec_path: str) -> Dict[str, Any]:
    return ORC.run_backtest_on_spec(spec_path)

@activity.defn
async def act_quick_refine(spec_path: str, max_runs: int=6) -> Dict[str, Any]:
    return ORC.quick_refine(spec_path, max_runs=max_runs)

@activity.defn
async def act_select_best(results: List[Dict[str, Any]], primary: str="profit_factor") -> Dict[str, Any]:
    return ORC.select_best(results, primary=primary)

@activity.defn
async def act_forward_monitor(spec_path: str, period: str="30d", refresh_secs: int=300, cycles: int=6) -> Dict[str, Any]:
    return ORC.forward_monitor(spec_path, period=period, refresh_secs=refresh_secs, cycles=cycles)

# ---------- Workflow ----------
@workflow.defn
class BacktestWorkflow:
    @workflow.run
    async def run(self, spec_path: str, period: str="30d", refine_runs: int=6,
                  do_forward: bool=False, forward_cycles: int=6, forward_refresh_secs: int=300) -> Dict[str, Any]:
        # build deep CSV (reliable pack), backtest, refine, select best, optionally forward-monitor
        spec = json.loads(Path(spec_path).read_text(encoding="utf-8"))
        symbol = spec.get("symbol", "AUDCAD")
        timeframe = spec.get("timeframe", "5m")

        deep = await workflow.execute_activity(
            act_build_deep_csv, symbol, timeframe, period,
            start_to_close_timeout=workflow.timedelta(seconds=120)
        )

        base = await workflow.execute_activity(
            act_run_spec, spec_path,
            start_to_close_timeout=workflow.timedelta(seconds=120)
        )

        refine = await workflow.execute_activity(
            act_quick_refine, spec_path, refine_runs,
            start_to_close_timeout=workflow.timedelta(seconds=300)
        )
        best = await workflow.execute_activity(
            act_select_best, refine["runs"], "profit_factor",
            start_to_close_timeout=workflow.timedelta(seconds=60)
        )

        out: Dict[str, Any] = {"deep_csv": deep, "base": base, "refine": refine, "best": best}

        if do_forward:
            fwd = await workflow.execute_activity(
                act_forward_monitor, spec_path, period, forward_refresh_secs, forward_cycles,
                start_to_close_timeout=workflow.timedelta(seconds=forward_refresh_secs*forward_cycles + 120)
            )
            out["forward"] = fwd

        return out

# ---------- Entrypoint to run worker ----------
async def main():
    client = await Client.connect("localhost:7233")
    worker = Worker(
        client,
        task_queue="bt-orchestrator",
        workflows=[BacktestWorkflow],
        activities=[act_build_deep_csv, act_run_spec, act_quick_refine, act_select_best, act_forward_monitor],
    )
    print("Worker started on task queue: bt-orchestrator")
    await worker.run()

if __name__ == "__main__":
    asyncio.run(main())
