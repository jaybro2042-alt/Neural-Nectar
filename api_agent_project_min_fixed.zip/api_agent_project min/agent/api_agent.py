﻿from __future__ import annotations
# --- safe openai types shim (non-invasive) ---
import sys, types
try:
    import openai  # ensure the real package is imported; do not fabricate a top-level
except Exception:
    openai = None  # keep going; we'll only create the *submodule* if needed

tool_mod_name = "openai.types.responses.tool"

# Create only the submodule chain if it's truly missing (without replacing top-level 'openai')
if tool_mod_name not in sys.modules:
    sys.modules.setdefault("openai.types", types.ModuleType("openai.types"))
    sys.modules.setdefault("openai.types.responses", types.ModuleType("openai.types.responses"))
    sys.modules[tool_mod_name] = types.ModuleType(tool_mod_name)

tool_mod = sys.modules[tool_mod_name]
if not hasattr(tool_mod, "WebSearchToolFilters"):
    class WebSearchToolFilters: pass
    tool_mod.WebSearchToolFilters = WebSearchToolFilters
if not hasattr(tool_mod, "Tool"):
    class Tool:
        def __init__(self, *args, **kwargs): pass
    tool_mod.Tool = Tool
# --- end shim ---

# --- compat shim for Agents SDK vs OpenAI types (WebSearchToolFilters, Tool) ---
import sys, types
def _patch_openai_types():
    # [shim] removed: do not shadow openaisys.modules.setdefault("openai.types", types.ModuleType("openai.types"))
    sys.modules.setdefault("openai.types.responses", types.ModuleType("openai.types.responses"))
    tool_mod = sys.modules.setdefault("openai.types.responses.tool", types.ModuleType("openai.types.responses.tool"))
    if not hasattr(tool_mod, "WebSearchToolFilters"):
        class WebSearchToolFilters:  # minimal placeholder
            pass
        tool_mod.WebSearchToolFilters = WebSearchToolFilters
    if not hasattr(tool_mod, "Tool"):
        class Tool:  # minimal placeholder
            def __init__(self, *args, **kwargs): pass
        tool_mod.Tool = Tool
_patch_openai_types()
# (optional) """api_agent main entry â€” orchestrator/agent glue"""

# --- compat shim for older openai missing WebSearchToolFilters ---
import sys, types
try:
    from openai.types.responses.tool import WebSearchToolFilters  # noqa: F401
except Exception:
    sys.modules.setdefault("openai.types", types.ModuleType("openai.types"))
    sys.modules.setdefault("openai.types.responses", types.ModuleType("openai.types.responses"))
    tool_mod = types.ModuleType("openai.types.responses.tool")
    class WebSearchToolFilters:  # minimal placeholder
        pass
    tool_mod.WebSearchToolFilters = WebSearchToolFilters
    sys.modules["openai.types.responses.tool"] = tool_mod

# --- standard imports (no duplicates) ---
import os
import json
import argparse
from typing import Any, Dict, List
from datetime import datetime
from pathlib import Path
import shutil

PROJECT_ROOT = Path(__file__).resolve().parents[1]
MASTER_CFG_PATH = PROJECT_ROOT / "master_config.json"

# (now it's safe to import the Agents SDK and your modules)
# from agents import Agent, Runner, SQLiteSession, function_tool
# ...rest of your file...


import re

DEFAULT_CFG = {
  "meta": {"name": "Main Trading Orchestrator", "version": "1.0.0"},
  "instructions": {"system": ["You are the Main Trading Orchestrator."], "style": {"plain_english": True, "reason_aloud": True}},
  "permissions": {"tools": {}, "file_edit": {"allow_globs": [], "deny_globs": []}, "network": {"yfinance": True, "http": False}, "temporal": {"enabled": True}},
  "tools": {"enabled": [], "defaults": {"primary_metric": "profit_factor", "symbol": "AUDCAD", "timeframe": "5m", "period": "30d"}}
}

def _parse_json_lenient(text: str) -> dict:
    # strip // and /* */ comments (naive but effective) and trailing commas
    s = re.sub(r'//.*', '', text)
    s = re.sub(r'/\*.*?\*/', '', s, flags=re.S)
    s = re.sub(r',(\s*[}\]])', r'\1', s)
    return json.loads(s)

def _load_master_cfg() -> Dict[str, Any]:
    if not MASTER_CFG_PATH.exists():
        MASTER_CFG_PATH.write_text(json.dumps(DEFAULT_CFG, indent=2), encoding="utf-8")
        return DEFAULT_CFG
    raw = MASTER_CFG_PATH.read_text(encoding="utf-8")
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        try:
            cfg = _parse_json_lenient(raw)
            # normalize file to strict JSON so it won't fail next boot
            MASTER_CFG_PATH.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
            return cfg
        except Exception:
            # back up the broken file and write defaults
            backup = MASTER_CFG_PATH.with_suffix(".bad.json")
            try: MASTER_CFG_PATH.replace(backup)
            except Exception: pass
            MASTER_CFG_PATH.write_text(json.dumps(DEFAULT_CFG, indent=2), encoding="utf-8")
            return DEFAULT_CFG

def _set_by_dotted(doc: Dict[str, Any], dotted: str, value: Any) -> None:
    cur = doc
    parts = [p for p in dotted.split(".") if p]
    for p in parts[:-1]:
        if p not in cur or not isinstance(cur[p], dict):
            cur[p] = {}
        cur = cur[p]
    cur[parts[-1]] = value


# deps: pip install openai openai-agents colorama
from agents import Agent, Runner, SQLiteSession, function_tool
from colorama import init as colorama_init, Fore, Style

# Try to import hosted tools; fall back gracefully if not available
try:
    from agents import WebSearchTool, CodeInterpreterTool, FileSearchTool  # type: ignore
    _HOSTED_TOOLS_AVAILABLE = True
except Exception:
    WebSearchTool = CodeInterpreterTool = FileSearchTool = None  # type: ignore
    _HOSTED_TOOLS_AVAILABLE = False

colorama_init()
GREEN = Fore.GREEN
YELLOW = Fore.YELLOW
CYAN = Fore.CYAN
RED = Fore.RED
RESET = Style.RESET_ALL

PROJECT_ROOT = Path(__file__).resolve().parents[1]


# ---------------- Orchestrator glue ----------------
def _ensure_orc():
    """Import your orchestrator. Fails fast with a friendly message."""
    try:
        from orchestrator import core as ORC  # expects ensure_ohlcv, validate_csv, run_backtest_on_spec, quick_refine, select_best
        return ORC
    except Exception as e:
        raise RuntimeError(
            "Cannot import orchestrator.core. Ensure 'orchestrator/core.py' exists and "
            "implements: ensure_ohlcv(), validate_csv(), run_backtest_on_spec(), "
            "quick_refine(), select_best()."
        ) from e


# ---------------- Function tools (callable by model) ----------------
@function_tool
def ensure_ohlcv(symbol: str, timeframe: str, period: str = "30d", auto_adjust: bool = True) -> Dict[str, Any]:
    """Fetch and store OHLCV via yfinance and write a CSV."""
    ORC = _ensure_orc()
    return ORC.ensure_ohlcv(symbol, timeframe, period=period, auto_adjust=auto_adjust)

@function_tool
def validate_csv(path: str) -> Dict[str, Any]:
    """Validate a CSV has columns: datetime, open, high, low, close, volume."""
    ORC = _ensure_orc()
    return ORC.validate_csv(path)

@function_tool
def run_backtest_on_spec(spec_path: str) -> Dict[str, Any]:
    """Run a Backtrader backtest using a strategy JSON spec. Returns metrics."""
    ORC = _ensure_orc()
    return ORC.run_backtest_on_spec(spec_path)

@function_tool
def quick_refine(spec_path: str, max_runs: int = 6) -> Dict[str, Any]:
    """Try several parameter variants and return a 'runs' list with metrics."""
    ORC = _ensure_orc()
    return ORC.quick_refine(spec_path, max_runs=max_runs)

@function_tool
def select_best(results_json: str, primary: str = "sharpeA") -> Dict[str, Any]:
    """Pick best run by metric from a JSON string containing a 'runs' list."""
    ORC = _ensure_orc()
    try:
        results = json.loads(results_json)
    except Exception:
        results = []
    return ORC.select_best(results, primary=primary)
@function_tool
def ensure_ohlcv_plus_tool(symbol: str, timeframe: str, period: str="30d", indicators_json: str="[]", strict: bool=False) -> Dict[str, Any]:
    """Fetch OHLCV and add best-effort indicators into CSV. pass indicators_json as a JSON list of names."""
    ORC = _ensure_orc()
    try:
        inds = json.loads(indicators_json) if indicators_json else []
    except Exception:
        inds = []
    return ORC.ensure_ohlcv_plus(symbol, timeframe, period=period, indicators=inds, strict=strict)

@function_tool
def forward_monitor_tool(spec_path: str, period: str="30d", refresh_secs: int=300, cycles: int=6) -> Dict[str, Any]:
    """Periodically refetch data & re-run backtest; returns a history of metrics."""
    ORC = _ensure_orc()
    return ORC.forward_monitor(spec_path, period=period, refresh_secs=refresh_secs, cycles=cycles)

@function_tool
def build_deep_csv(symbol: str, timeframe: str, period: str="30d") -> Dict[str, Any]:
    """Build a deep CSV with default indicator pack; skips unreliable indicators automatically."""
    ORC = _ensure_orc()
    return ORC.ensure_ohlcv_plus(symbol, timeframe, period=period, indicators=None, strict=False)
from agents import function_tool

@function_tool
def get_master_config() -> Dict[str, Any]:
    """Return current master config JSON."""
    return _load_master_cfg()

@function_tool
def set_master_config(path: str, value_json: str) -> Dict[str, Any]:
    """Update master_config.json at dotted path with a JSON value string; returns diff."""
    cfg = _load_master_cfg()
    try:
        new_val = json.loads(value_json)
    except Exception as e:
        return {"ok": False, "error": f"value_json is not valid JSON: {e}"}
    before = json.dumps(cfg, sort_keys=True)
    _set_by_dotted(cfg, path, new_val)
    MASTER_CFG_PATH.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
    after = json.dumps(cfg, sort_keys=True)
    return {"ok": True, "changed": before != after}

@function_tool
def reload_master_config() -> Dict[str, Any]:
    """Hint to the host REPL to reload config (no effect by itself)."""
    # This tool just returns the current config; the chat loop watches for !!reload to actually rebuild the Agent.
    return {"ok": True, "config": _load_master_cfg()}


# --------- Project self-fix tools ---------
@function_tool
def patch_file(path: str, find: str, replace: str, backup: bool = True) -> Dict[str, Any]:
    """String-replace inside a text file. Returns counts and backup path if made."""
    p = (PROJECT_ROOT / path) if not Path(path).is_absolute() else Path(path)
    if not p.exists():
        return {"ok": False, "error": f"file not found: {p}"}
    txt = p.read_text(encoding="utf-8")
    cnt = txt.count(find)
    if cnt == 0:
        return {"ok": True, "replacements": 0}
    if backup:
        bak = p.with_suffix(p.suffix + ".bak")
        bak.write_text(txt, encoding="utf-8")
        bak_str = str(bak)
    else:
        bak_str = ""
    new_txt = txt.replace(find, replace)
    p.write_text(new_txt, encoding="utf-8")
    return {"ok": True, "replacements": cnt, "backup": bak_str}

@function_tool
def append_line(path: str, line: str) -> Dict[str, Any]:
    """Append a single line to a text file (creates file if needed)."""
    p = (PROJECT_ROOT / path) if not Path(path).is_absolute() else Path(path)
    with p.open("a", encoding="utf-8") as f:
        f.write(line + "\n")
    return {"ok": True, "path": str(p)}


# --------- Local helpers (self-contained) ---------
def _reports_dir(name: str) -> Path:
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    d = PROJECT_ROOT / "reports" / f"{ts}_{name}"
    d.mkdir(parents=True, exist_ok=True)
    return d

@function_tool
def list_strategies() -> Dict[str, Any]:
    """List strategy JSON files under strategies/."""
    p = PROJECT_ROOT / "strategies"
    files = []
    if p.exists():
        files = [str(f.relative_to(PROJECT_ROOT)) for f in p.glob("*.json")]
    return {"strategies": files}

@function_tool
def write_report(spec_path: str, results_json: str, outdir: str = "reports") -> Dict[str, Any]:
    """Write Markdown + JSON report for a backtest run.
    IMPORTANT: pass results_json as a JSON string, not an object.
    """
    spec_path = (PROJECT_ROOT / spec_path).resolve()
    spec = json.loads(spec_path.read_text(encoding="utf-8"))
    try:
        results = json.loads(results_json) if results_json else {}
    except Exception:
        results = {}

    name = spec.get("name", spec_path.stem)
    repdir = _reports_dir(name)

    payload = {"spec": spec, "results": results, "created_at": datetime.now().isoformat(), "version": 1}
    (repdir / "report.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")

    lines: List[str] = []
    lines.append(f"# Backtest Report â€” {name}")
    lines.append("")
    lines.append(f"- Spec: `{spec_path.relative_to(PROJECT_ROOT)}`")
    m = (results or {}).get("metrics", {}) or {}
    if m:
        lines.append("")
        lines.append("## Metrics")
        for k in ["sharpeA","winrate","total_trades","max_drawdown_pct","avg_drawdown_pct","sqn","rtot","ravg","bars"]:
            if k in m and m[k] is not None:
                lines.append(f"- **{k}**: {m[k]}")
    (repdir / "report.md").write_text("\n".join(lines), encoding="utf-8")

    return {"report_dir": str(repdir.relative_to(PROJECT_ROOT)), "files": ["report.json","report.md"]}

@function_tool
def organize_project(dry_run: bool = True) -> Dict[str, Any]:
    """Move stray .json/.csv/.md into canonical folders (strategies/, data/, reports/)."""
    moves: List[Dict[str, str]] = []
    strat_dir = PROJECT_ROOT / "strategies"
    data_dir = PROJECT_ROOT / "data"
    rep_dir = PROJECT_ROOT / "reports"
    strat_dir.mkdir(exist_ok=True); data_dir.mkdir(exist_ok=True); rep_dir.mkdir(exist_ok=True)

    for f in PROJECT_ROOT.glob("*.json"):
        dst = strat_dir / f.name
        if f != dst:
            moves.append({"from": str(f), "to": str(dst)})
            if not dry_run:
                shutil.move(str(f), str(dst))

    for f in PROJECT_ROOT.glob("*.csv"):
        dst = data_dir / f.name
        if f != dst:
            moves.append({"from": str(f), "to": str(dst)})
            if not dry_run:
                shutil.move(str(f), str(dst))

    for f in PROJECT_ROOT.glob("*.md"):
        if f.name.lower() == "readme.md":
            continue
        dst = rep_dir / f.name
        if f != dst:
            moves.append({"from": str(f), "to": str(dst)})
            if not dry_run:
                shutil.move(str(f), str(dst))

    return {"dry_run": dry_run, "moves": moves}


# ---------------- Build the main agent ----------------
def build_agent() -> Agent:
    cfg = _load_master_cfg()

    # Base instructions from config (join lines)
    sys_lines = cfg.get("instructions", {}).get("system", []) or []
    instructions = "\n".join(sys_lines)

    # Which tools are allowed by permissions & enabled list
    enabled = set((cfg.get("tools", {}).get("enabled", []) or []))

    # Map logical names from config -> actual callable tools/hosted tools
    tool_map: Dict[str, Any] = {
        "ensure_ohlcv": ensure_ohlcv,
        "ensure_ohlcv_plus": ensure_ohlcv_plus_tool,
        "build_deep_csv": build_deep_csv,
        "validate_csv": validate_csv,
        "run_backtest_on_spec": run_backtest_on_spec,
        "quick_refine": quick_refine,
        "select_best": select_best,
        "forward_monitor": forward_monitor_tool,
        "write_report": write_report,
        "organize_project": organize_project,
        "patch_file": patch_file,
        "append_line": append_line,
        "get_master_config": get_master_config,
        "set_master_config": set_master_config,
        "reload_master_config": reload_master_config,
    }

    tools_final: List[Any] = []
    # Add built-in/function tools
    for key, fn in tool_map.items():
        if key in enabled:
            tools_final.append(fn)

    # Hosted tools (guarded by permissions)
    perms = cfg.get("permissions", {})
    perms_tools = (perms.get("tools") or {})
    if perms_tools.get("web_search") and WebSearchTool:
        try: tools_final.append(WebSearchTool())  # type: ignore
        except Exception: pass
    if perms_tools.get("code_interpreter") and CodeInterpreterTool:
        try: tools_final.append(CodeInterpreterTool())  # type: ignore
        except Exception: pass
    if perms_tools.get("file_search") and FileSearchTool:
        try:
            vs_ids = os.environ.get("OPENAI_VECTOR_STORE_IDS", "").strip()
            if vs_ids:
                tools_final.append(FileSearchTool(max_num_results=4, vector_store_ids=[s.strip() for s in vs_ids.split(",") if s.strip()]))  # type: ignore
        except Exception: pass

    model_name = os.environ.get("OPENAI_MODEL", "gpt-5-mini")
    return Agent(
        name=cfg.get("meta", {}).get("name", "Main Trading Orchestrator"),
        instructions=instructions,
        model=model_name,
        tools=tools_final,
    )

def chat(session_id: str = "default", multiline: bool = True):
    """Interactive console with multi-line paste blocks and !!reload."""
    session = SQLiteSession(session_id)
    agent = build_agent()

    print(f"{CYAN}Main Agent â€” session: {session_id}{RESET}")
    print("Paste a single line and press Enter;")
    print("or enter ``` on a line by itself to START/END a multi-line block.")
    print("Commands: !!reload (rebuild agent from master_config.json), !!quit")
    print("")

    reading_block = False
    buf: List[str] = []

    while True:
        try:
            prompt = "â€¦ " if reading_block else "you â€º "
            line = input(f"{YELLOW}{prompt}{RESET}")
        except (EOFError, KeyboardInterrupt):
            print("\nbye."); break

        if line is None:
            continue
        s = line.rstrip("\r\n")

        # commands (only when not inside a block)
        if not reading_block and s.strip() in {"!!quit", "!!exit"}:
            print("bye."); break
        if not reading_block and s.strip() == "!!reload":
            agent = build_agent()
            print(f"{GREEN}reloaded master_config and rebuilt agent{RESET}")
            continue

        # toggle multiline with ```
        if multiline and s.strip() == "```":
            reading_block = not reading_block
            if reading_block:
                buf.clear()
                print("(multiline mode: paste; end with ```)")
                continue
            else:
                user_in = "\n".join(buf).strip()
                buf.clear()
                if not user_in:
                    continue
        elif reading_block:
            buf.append(s)
            continue
        else:
            user_in = s.strip()
            if not user_in:
                continue

        # run the agent
        try:
            result = Runner.run_sync(agent, user_in, session=session, max_turns=2000)
            print(f"{GREEN}agent â€º {RESET}{result.final_output}\n")
        except Exception as e:
            print(f"{RED}[agent error]{RESET} {e}")


def main():
    ap = argparse.ArgumentParser(description="Main Trading Orchestrator (OpenAI Agents SDK)")
    ap.add_argument("--chat", action="store_true", help="Start interactive chat (default if no args)")
    ap.add_argument("--ask", type=str, default=None, help="Run a single question and print the answer")
    ap.add_argument("--session", type=str, default="default", help="Session id for memory")
    args = ap.parse_args()

    if args.ask:
        raise SystemExit(one_off(args.ask, session_id=args.session))

    # default to chat
    chat(session_id=args.session)


if __name__ == "__main__":
    main()


from agents import function_tool
@function_tool
def pip_install(args: str) -> dict:
    """Run pip install inside this environment. Example: args="-U openai openai-agents" """
    import subprocess, sys, shlex
    cmd = [sys.executable, "-m", "pip", "install"] + shlex.split(args)
    p = subprocess.run(cmd, capture_output=True, text=True)
    return {
        "ok": p.returncode == 0,
        "cmd": " ".join(cmd),
        "stdout_tail": p.stdout[-4000:],
        "stderr_tail": p.stderr[-4000:]
    }


try:
    _orig_build_agent = build_agent  # type: ignore[name-defined]
    def build_agent():  # type: ignore[func-override]
        agent = _orig_build_agent()
        try:
            cfg = _load_master_cfg()
            enabled = set((cfg.get("tools", {}).get("enabled", []) or []))
            if "pip_install" in enabled:
                if not any(getattr(t, "__name__", "") == "pip_install" for t in getattr(agent, "tools", [])):
                    agent.tools.append(pip_install)  # make tool visible at runtime
        except Exception:
            pass
        return agent
except NameError:
    pass



