#!/usr/bin/env python3
import os
import sys
import json
import shutil
import datetime
import time
from pathlib import Path

BASE = Path(__file__).resolve().parent

# Paths
STRAT_DIR = BASE / "strategies"
ACTIVE_DIR = STRAT_DIR / "active"
ARCHIVE_DIR = STRAT_DIR / "archive"
BACKUPS_DIR = STRAT_DIR / "backups"
PATCH_BACKUPS_DIR = STRAT_DIR / "patch_backups"
PERM_LOG = STRAT_DIR / "permissions_grants.log"
MANIFEST = STRAT_DIR / "organize_manifest.json"
FINAL_REPORT = BASE / "final_report.json"
DATA_DIR = BASE / "data"

# Config
DEFAULT_SYMBOL = "AUDCAD"
DEFAULT_TIMEFRAME = "5m"
DEFAULT_PERIOD = "60d"
OPT_MAX_RUNS = 24
REFINE_MAX_RUNS = 12
OPT_ITERATIONS = 4

def ts_now():
    return datetime.datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")

def ensure_dirs():
    for d in [STRAT_DIR, ACTIVE_DIR, ARCHIVE_DIR, BACKUPS_DIR, PATCH_BACKUPS_DIR, DATA_DIR]:
        d.mkdir(parents=True, exist_ok=True)

def backup_master_config():
    src = BASE / "master_config.json"
    if not src.exists():
        print("No master_config.json found at project root; skipping backup.")
        return None
    dst = BACKUPS_DIR / f"master_config_backup_{ts_now()}.json"
    shutil.copy2(src, dst)
    print(f"Backed up master_config.json -> {dst}")
    return dst

def log_permission(action_desc, granted_by="user"):
    PERM_LOG.parent.mkdir(parents=True, exist_ok=True)
    entry = {
        "timestamp": datetime.datetime.utcnow().isoformat(),
        "action": action_desc,
        "granted_by": granted_by
    }
    with open(PERM_LOG, "a", encoding="utf-8") as f:
        f.write(json.dumps(entry) + "\n")
    print(f"Logged permission: {action_desc}")

def find_strategy_jsons():
    if not STRAT_DIR.exists():
        return []
    return [p for p in STRAT_DIR.glob("*.json") if p.is_file() and p.name != "organize_manifest.json"]

def group_by_basename(paths):
    groups = {}
    for p in paths:
        base = p.stem
        groups.setdefault(base, []).append(p)
    return groups

def select_newest(paths):
    return max(paths, key=lambda p: p.stat().st_mtime)

def organize_strategies():
    jsons = find_strategy_jsons()
    groups = group_by_basename(jsons)
    manifest = []
    for base, files in groups.items():
        newest = select_newest(files)
        for f in files:
            if f == newest:
                dst = ACTIVE_DIR / f.name
                action = "copied_to_active"
            else:
                dst = ARCHIVE_DIR / f.name
                action = "moved_to_archive"
            # copy newest to active, copy others to archive (safe)
            shutil.copy2(f, dst)
            manifest.append({
                "src": str(f),
                "dst": str(dst),
                "action": action,
                "timestamp": ts_now()
            })
    with open(MANIFEST, "w", encoding="utf-8") as mf:
        json.dump({"moved": manifest, "timestamp": datetime.datetime.utcnow().isoformat()}, mf, indent=2)
    print(f"Organized strategies. Manifest written to {MANIFEST}")
    return manifest

# Patch patterns for hard-coded turn-limits
import re
PY_PATTERN = re.compile(r'(^\s*turn_limit\s*=\s*)(\d+)', flags=re.M)
JSON_PATTERN = re.compile(r'("turn_limit"\s*:\s*)(\d+)', flags=re.I)

def backup_file(p: Path):
    PATCH_BACKUPS_DIR.mkdir(parents=True, exist_ok=True)
    bak = PATCH_BACKUPS_DIR / f"{p.name}.bak.{ts_now()}"
    shutil.copy2(p, bak)
    return bak

def patch_py_file(p: Path):
    text = p.read_text(encoding="utf-8")
    if not PY_PATTERN.search(text):
        return False
    bak = backup_file(p)
    repl = 'turn_limit = int(os.getenv("TURN_LIMIT", "0"))'
    new_text = PY_PATTERN.sub(repl, text)
    if "import os" not in new_text:
        new_text = "import os\n" + new_text
    p.write_text(new_text, encoding="utf-8")
    print(f"Patched {p} (backup: {bak.name})")
    return True

def patch_json_file(p: Path):
    text = p.read_text(encoding="utf-8")
    if not JSON_PATTERN.search(text):
        return False
    bak = backup_file(p)
    repl = '"turn_limit": {"env":"TURN_LIMIT","default":0}'
    new_text = JSON_PATTERN.sub(repl, text)
    p.write_text(new_text, encoding="utf-8")
    print(f"Patched {p} (backup: {bak.name})")
    return True

def scan_and_patch():
    patched = []
    for root, dirs, files in os.walk(BASE):
        # skip backups and venvs
        if any(skip in root for skip in [".venv", "venv", "site-packages", str(BACKUPS_DIR), str(PATCH_BACKUPS_DIR)]):
            continue
        for fname in files:
            p = Path(root) / fname
            if p.name == "master_config.json":
                continue
            if p.suffix == ".py":
                try:
                    if patch_py_file(p):
                        patched.append(str(p))
                except Exception as e:
                    print(f"Failed patching {p}: {e}")
            elif p.suffix == ".json":
                try:
                    if patch_json_file(p):
                        patched.append(str(p))
                except Exception as e:
                    print(f"Failed patching {p}: {e}")
    print(f"Patched {len(patched)} files.")
    return patched

# Convert EMA-style JSON spec to Backtrader template
BT_TEMPLATE = '''import backtrader as bt

class {class_name}(bt.Strategy):
    params = {params_repr}

    def __init__(self):
        self.ema_fast = bt.ind.EMA(self.data.close, period=self.p.ema_fast)
        self.ema_slow = bt.ind.EMA(self.data.close, period=self.p.ema_slow)

    def next(self):
        if not self.position:
            if self.ema_fast[0] > self.ema_slow[0] and self.ema_fast[-1] <= self.ema_slow[-1]:
                size = int(self.broker.getcash() / self.data.close[0])
                if size > 0:
                    self.buy(size=size)
        else:
            if self.ema_fast[0] < self.ema_slow[0] and self.ema_fast[-1] >= self.ema_slow[-1]:
                self.close()
'''

def convert_to_backtrader():
    bt_out = ACTIVE_DIR / "backtrader"
    bt_out.mkdir(parents=True, exist_ok=True)
    converted = []
    for spec in ACTIVE_DIR.glob("*.json"):
        try:
            data = json.loads(spec.read_text(encoding="utf-8"))
        except Exception:
            continue
        stype = data.get("strategy", {}).get("type", data.get("type", "ema_crossover"))
        params = data.get("strategy", {}).get("params", data.get("params", {}))
        if stype == "ema_crossover":
            cls_name = spec.stem.replace("-", "_").title().replace("_", "")
            params_default = {"ema_fast": params.get("ema_fast", 10), "ema_slow": params.get("ema_slow", 20)}
            out = BT_TEMPLATE.format(class_name=cls_name, params_repr=params_default)
            out_path = bt_out / (spec.stem + ".py")
            out_path.write_text(out, encoding="utf-8")
            converted.append(str(out_path))
            print(f"Converted {spec.name} -> {out_path}")
    return converted

# Backtest & optimization using orchestrator.core
def import_orchestrator_core():
    try:
        import orchestrator.core as core
        return core
    except Exception as e:
        print("Failed to import orchestrator.core. Ensure orchestrator/core.py exists and is importable.")
        print("Error:", e)
        return None

def run_backtests_and_optimize(core_mod):
    results = []
    specs = list(ACTIVE_DIR.glob("*.json"))
    if not specs:
        print("No specs found in strategies/active. Exiting backtest step.")
        return {"results": [], "best": None}
    # Ensure data is fetched once using default symbol/timeframe/period if needed.
    # Let orchestrator.core.ensure_ohlcv handle the download in run_backtest_on_spec
    for s in specs:
        print(f"Backtesting spec: {s.name}")
        try:
            res = core_mod.run_backtest_on_spec(str(s))
        except Exception as e:
            print(f"Backtest error for {s.name}: {e}")
            res = {"ok": False, "error": str(e), "spec": str(s)}
        # collect main metrics if available
        metrics = {
            "spec": str(s),
            "profit_factor": res.get("profit_factor"),
            "expectancy": res.get("expectancy"),
            "winrate": res.get("winrate"),
            "rtot": res.get("rtot"),
            "ravg": res.get("ravg"),
            "max_drawdown_pct": res.get("max_drawdown_pct"),
            "ntrades": res.get("ntrades"),
            "ok": res.get("ok", False),
            "data_csv": res.get("data_csv")
        }
        results.append({"spec": str(s), "metrics": metrics, "raw": res})
        time.sleep(0.5)
    # Rank by profit_factor (higher is better). Handle None => -inf
    def pf_key(item):
        v = item["metrics"].get("profit_factor")
        if v is None:
            return float("-inf")
        try:
            return float(v)
        except Exception:
            return float("-inf")
    ranked = sorted(results, key=pf_key, reverse=True)
    best_entry = ranked[0] if ranked else None

    # Run quick_refine on each spec (light) and then focused optimize best
    refine_summaries = []
    for r in ranked:
        sp = Path(r["spec"])
        print(f"Quick refine for {sp.name} (max {REFINE_MAX_RUNS})")
        try:
            qr = core_mod.quick_refine(str(sp), max_runs=REFINE_MAX_RUNS)
        except Exception as e:
            print(f"quick_refine error for {sp.name}: {e}")
            qr = {"ok": False, "error": str(e)}
        refine_summaries.append({"spec": str(sp), "quick_refine": qr})
        time.sleep(0.5)

    optimized_best = None
    if best_entry:
        best_spec_path = Path(best_entry["spec"])
        print(f"Optimizing best spec: {best_spec_path.name}")
        current_spec = best_spec_path
        best_overall = None
        for i in range(OPT_ITERATIONS):
            print(f"Optimization iteration {i+1}/{OPT_ITERATIONS} for {current_spec.name}")
            try:
                res = core_mod.quick_refine(str(current_spec), max_runs=OPT_MAX_RUNS)
            except Exception as e:
                print(f"quick_refine error: {e}")
                break
            if not res.get("ok"):
                print("quick_refine failed or returned no runs.")
                break
            select = core_mod.select_best(res, primary='profit_factor')
            if not select.get("ok"):
                print("select_best found no suitable run.")
                break
            best_run = select.get("best")
            if not best_run:
                print("No best run returned.")
                break
            # compare
            pf = best_run.get("profit_factor", -9999)
            if best_overall is None or pf > best_overall.get("profit_factor", -9999):
                best_overall = best_run
                # write a new spec file with the best params to continue refining
                params = best_run.get("run_params", {})
                new_spec = current_spec.with_suffix(f".opt.{i+1}.json")
                spec_json = json.loads(Path(current_spec).read_text(encoding="utf-8"))
                if "strategy" not in spec_json:
                    spec_json["strategy"] = {}
                spec_json["strategy"]["params"] = params
                new_spec.write_text(json.dumps(spec_json, indent=2), encoding="utf-8")
                current_spec = new_spec
                print(f"New improved spec written: {new_spec.name} with profit_factor={pf}")
            else:
                print("No improvement; ending optimization.")
                break
        optimized_best = best_overall

    return {"results": ranked, "refines": refine_summaries, "optimized_best": optimized_best}

def write_final_report(report):
    with open(FINAL_REPORT, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2)
    print(f"Final report written to {FINAL_REPORT}")

def main():
    print("=== Combined runner starting ===")
    ensure_dirs()
    # log that we were granted permission (user already granted via chat)
    log_permission("Grant: create directories and organize strategies", granted_by=os.getenv("USERNAME", "user"))
    # backup master_config
    backup_master_config()
    # organize
    manifest = organize_strategies()
    # scan & patch
    patched = scan_and_patch()
    # convert
    converted = convert_to_backtrader()
    # import orchestrator.core
    core_mod = import_orchestrator_core()
    if core_mod is None:
        print("Cannot proceed with backtests because orchestrator.core is not importable in this environment.")
        print("Make sure orchestrator/core.py exists and try again.")
        # still write a partial report
        write_final_report({
            "timestamp": datetime.datetime.utcnow().isoformat(),
            "manifest": manifest,
            "patched_files": patched,
            "converted": converted,
            "backtests_run": False,
            "note": "orchestrator.core not importable; please ensure the module exists and re-run to perform backtests/optimization."
        })
        return
    # run backtests & optimize
    bt_results = run_backtests_and_optimize(core_mod)
    # build report
    report = {
        "timestamp": datetime.datetime.utcnow().isoformat(),
        "manifest": manifest,
        "patched_files": patched,
        "converted_backtrader": converted,
        "backtest_summary": [r["metrics"] for r in bt_results.get("results", [])],
        "refine_summaries": bt_results.get("refines"),
        "optimized_best": bt_results.get("optimized_best")
    }
    write_final_report(report)
    print("=== Combined runner finished ===")

if __name__ == "__main__":
    main()