
from __future__ import annotations
from pathlib import Path
from typing import Dict, Any
import json
import pandas as pd

# Optional imports done inside functions to avoid hard-fails
try:
    import yfinance as yf
except Exception:
    yf = None

STRATS = Path("strategies")
DATA_DIR = Path("data")
DATA_DIR.mkdir(exist_ok=True)
STRATS.mkdir(exist_ok=True)

def _csv_path(symbol: str, timeframe: str) -> Path:
    return DATA_DIR / f"{symbol.replace('/', '_')}_{timeframe}.csv"

def _yf_ticker(symbol: str) -> str:
    s = symbol.strip().upper()
    if "/" in s:
        base, quote = s.split("/", 1)
        return f"{base}{quote}=X"
    return s

def _interval_from_timeframe(tf: str) -> str:
    tf = tf.strip().lower()
    mapping = {"1m":"1m","2m":"2m","5m":"5m","15m":"15m","30m":"30m","60m":"60m","90m":"90m","1d":"1d"}
    return mapping.get(tf, "5m")

def validate_csv(path: str) -> dict:
    p = Path(path)
    if not p.exists():
        return {"ok": False, "reason": "missing"}
    import csv
    with open(p, "r", newline="") as f:
        header = next(csv.reader(f), [])
    expected = ["datetime","open","high","low","close","volume"]
    ok = [h.strip().lower() for h in header] == expected
    return {"ok": ok, "header": header, "expected": expected}

def ensure_ohlcv(symbol: str, timeframe: str, period: str = "30d", auto_adjust: bool = True) -> Dict[str, Any]:
    p = _csv_path(symbol, timeframe)
    if yf is None:
        return {"ok": False, "error": "yfinance not installed; pip install yfinance", "csv": str(p)}
    ticker = _yf_ticker(symbol)
    interval = _interval_from_timeframe(timeframe)
    try:
        df = yf.download(tickers=ticker, period=period, interval=interval, auto_adjust=auto_adjust, progress=False, threads=False)
    except Exception as e:
        return {"ok": False, "error": f"yfinance download failed: {e}", "csv": str(p), "ticker": ticker, "interval": interval}
    if df is None or df.empty:
        return {"ok": False, "error": "empty dataframe from Yahoo", "csv": str(p), "ticker": ticker, "interval": interval}
    out = pd.DataFrame({
        "datetime": df.index.tz_localize(None).strftime("%Y-%m-%d %H:%M:%S"),
        "open": df["Open"].astype(float).round(6),
        "high": df["High"].astype(float).round(6),
        "low": df["Low"].astype(float).round(6),
        "close": df["Close"].astype(float).round(6),
        "volume": df["Volume"].fillna(0).astype(int),
    })[["datetime","open","high","low","close","volume"]]
    p.parent.mkdir(parents=True, exist_ok=True)
    out.to_csv(p, index=False)
    return {"ok": True, "rows": int(len(out)), "csv": str(p), "ticker": ticker, "interval": interval, "period": period}

def _bt_timeframe_and_compression(tf: str):
    import backtrader as bt
    tf = tf.lower()
    if tf.endswith("m"):
        return bt.TimeFrame.Minutes, int(tf[:-1] or 1)
    if tf.endswith("h"):
        return bt.TimeFrame.Minutes, int(tf[:-1]) * 60
    if tf.endswith("d"):
        return bt.TimeFrame.Days, 1
    return bt.TimeFrame.Minutes, 5

def run_backtest_on_spec(spec_path: str) -> dict:
    spec = json.loads(Path(spec_path).read_text(encoding="utf-8"))
    symbol = spec.get("universe", ["AUD/CAD"])[0]
    timeframe = spec.get("timeframe", "5m")
    csv = _csv_path(symbol, timeframe)
    if not Path(csv).exists():
        ensure_ohlcv(symbol, timeframe)

    try:
        import backtrader as bt
        from bt_strategy_from_json import StrategyFromJSON
    except Exception as e:
        return {"ok": False, "error": f\"Backtrader not available ({e}). pip install backtrader.\"}

    data = bt.feeds.GenericCSVData(
        dataname=str(csv),
        dtformat="%Y-%m-%d %H:%M:%S",
        datetime=0, open=1, high=2, low=3, close=4, volume=5, openinterest=-1,
        timeframe=_bt_timeframe_and_compression(timeframe)[0],
        compression=_bt_timeframe_and_compression(timeframe)[1],
        nullvalue=0.0,
        headers=True,
    )

    cerebro = bt.Cerebro(stdstats=False)
    # Params from JSON
    p = spec.get("params", {})
    risk = spec.get("risk", {})
    stop_expr = risk.get("stop", f"2*ATR({int(p.get('atr', 14))})")
    strategy_params = dict(
        ema=int(p.get("ema", 20)),
        rsi=int(p.get("rsi", 14)),
        atr=int(p.get("atr", 14)),
        risk_pct=float(risk.get("risk_pct", 0.5)),
        stop_expr=str(stop_expr),
    )

    cerebro.addstrategy(StrategyFromJSON, **strategy_params)
    cerebro.adddata(data)
    cerebro.broker.setcash(100000.0)
    cerebro.broker.setcommission(commission=0.0002)  # ~2 bps placeholder
    cerebro.addanalyzer(bt.analyzers.SharpeRatio_A, _name="sharpeA")
    cerebro.addanalyzer(bt.analyzers.DrawDown, _name="dd")
    cerebro.addanalyzer(bt.analyzers.TradeAnalyzer, _name="trades")
    cerebro.addanalyzer(bt.analyzers.Returns, _name="returns")
    cerebro.addanalyzer(bt.analyzers.SQN, _name="sqn")

    strat = cerebro.run(maxcpus=1)[0]
    A = strat.analyzers

    def _safe(a, attr, default=None):
        try:
            v = getattr(a, attr)
            if callable(v): v = v()
            return v
        except Exception:
            return default

    sharpe = _safe(A.sharpeA, "get_analysis", {}).get("sharperatio", None)
    dd = _safe(A.dd, "get_analysis", {})
    trades = _safe(A.trades, "get_analysis", {})
    rets = _safe(A.returns, "get_analysis", {})
    sqn = _safe(A.sqn, "get_analysis", {}).get("sqn", None)

    return {
        "ok": True,
        "spec": spec,
        "metrics": {
            "sharpeA": sharpe,
            "max_drawdown_pct": dd.get("max", {}).get("drawdown", None),
            "avg_drawdown_pct": dd.get("avg", {}).get("drawdown", None),
            "total_trades": trades.get("total", {}).get("total", None),
            "won": trades.get("won", {}).get("total", None),
            "lost": trades.get("lost", {}).get("total", None),
            "winrate": (trades.get("won", {}).get("total", 0) / max(1, trades.get("total", {}).get("total", 1))),
            "sqn": sqn,
            "rtot": rets.get("rtot", None),
            "ravg": rets.get("ravg", None),
        },
        "data_source": "yfinance_csv",
        "csv": str(csv),
        "strategy_params": strategy_params,
    }

def quick_refine(spec_path: str, max_runs: int = 8) -> dict:
    return {"runs": [run_backtest_on_spec(spec_path) for _ in range(max_runs)]}

def select_best(results: list[dict], primary: str = "sharpeA", **constraints) -> dict:
    best = None; key = primary
    for r in results:
        val = (r.get("metrics", {}) or {}).get(key, None)
        if val is None: 
            continue
        if best is None or val > (best.get("metrics", {}) or {}).get(key, -1e9):
            best = r
    return {"winner": best}
