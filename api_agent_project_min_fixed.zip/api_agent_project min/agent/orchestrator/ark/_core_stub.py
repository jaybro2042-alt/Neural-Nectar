from __future__ import annotations
from pathlib import Path
import pandas as pd
import json

STRATS = Path("strategies")
DATA_DIR = Path("data")
DATA_DIR.mkdir(exist_ok=True)
STRATS.mkdir(exist_ok=True)

def _csv_path(symbol: str, timeframe: str) -> Path:
    return DATA_DIR / f"{symbol.replace('/','_')}_{timeframe}.csv"

def validate_csv(path: str) -> dict:
    p = Path(path)
    if not p.exists():
        return {"ok": False, "reason": "missing"}
    df = pd.read_csv(p)
    expected = ["datetime","open","high","low","close","volume"]
    ok = [c.lower() for c in df.columns.tolist()] == expected
    return {"ok": ok, "cols": df.columns.tolist(), "expected": expected}

def ensure_ohlcv(symbol: str, timeframe: str) -> dict:
    p = _csv_path(symbol, timeframe)
    if not p.exists():
        idx = pd.date_range("2024-01-01", periods=200, freq="T")
        import numpy as np
        prices = 100 + np.cumsum(np.random.randn(len(idx)) * 0.05)
        df = pd.DataFrame({
            "datetime": idx.strftime("%Y-%m-%d %H:%M:%S"),
            "open": prices,
            "high": prices + 0.1,
            "low": prices - 0.1,
            "close": prices + np.random.randn(len(idx))*0.02,
            "volume": 1000,
        })
        df.to_csv(p, index=False)
    return {"csv": str(p)}

def run_backtest_on_spec(spec_path: str) -> dict:
    spec = json.loads(Path(spec_path).read_text(encoding="utf-8"))
    uni = spec.get("universe", ["EUR/USD"])
    tf = spec.get("timeframe", "1m")
    csv = _csv_path(uni[0], tf)
    if not csv.exists():
        ensure_ohlcv(uni[0], tf)
    import numpy as np
    df = pd.read_csv(csv)
    rets = df["close"].pct_change().fillna(0.0)
    sharpe = float((rets.mean() / (rets.std() + 1e-9)) * (252*24*60) ** 0.5)
    return {"spec": spec, "metrics": {"sharpe": sharpe, "trades": int((rets.abs()>0.001).sum())}}

def quick_refine(spec_path: str, max_runs: int = 8) -> dict:
    out = [run_backtest_on_spec(spec_path) for _ in range(max_runs)]
    return {"runs": out}

def select_best(results: list[dict], primary: str = "sharpe", **constraints) -> dict:
    best = None
    for r in results:
        if best is None or r.get("metrics", {}).get(primary, -1e9) > best.get("metrics", {}).get(primary, -1e9):
            best = r
    return {"winner": best}
