
# orchestrator/runner_fallback.py — Backtrader fallback runner (if user's template not available)
import json
from pathlib import Path
import backtrader as bt

class GenericOHLCV(bt.feeds.GenericCSVData):
    params = (("dtformat","%Y-%m-%d %H:%M:%S"),
              ("datetime",0),("open",1),("high",2),("low",3),
              ("close",4),("volume",5),("openinterest",-1))

class Fallback(bt.Strategy):
    params = dict(spec=None)
    def __init__(self):
        P = (self.p.spec or {}).get("params", {})
        self.ema = bt.ind.EMA(self.data.close, period=int(P.get("ema", 20)))
        self.rsi = bt.ind.RSI(period=int(P.get("rsi", 14)))
    def next(self):
        if not self.position:
            if self.data.close[0] > self.ema[0] and self.rsi[0] > 55:
                self.buy()
            elif self.data.close[0] < self.ema[0] and self.rsi[0] < 45:
                self.sell()
        else:
            if self.position.size > 0 and self.rsi[0] < 45:
                self.close()
            elif self.position.size < 0 and self.rsi[0] > 55:
                self.close()

def run_backtest(spec_path: str, csv_path: str, cash: float = 100000.0, commission: float = 0.0002) -> dict:
    sp = Path(spec_path); spec = json.loads(sp.read_text(encoding="utf-8"))
    name = spec.get("name", sp.stem)
    cerebro = bt.Cerebro()
    cerebro.broker.setcash(cash)
    cerebro.broker.setcommission(commission=commission)
    cerebro.adddata(GenericOHLCV(dataname=str(csv_path)))
    cerebro.addstrategy(Fallback, spec=spec)
    cerebro.addanalyzer(bt.analyzers.DrawDown, _name="dd")
    cerebro.addanalyzer(bt.analyzers.TradeAnalyzer, _name="trades")
    try:
        cerebro.addanalyzer(bt.analyzers.SharpeRatio, _name="sharpe", timeframe=bt.TimeFrame.Days, annualize=True)
    except Exception:
        pass
    res = cerebro.run()[0]
    portvalue = cerebro.broker.getvalue()
    roi_pct = (portvalue / 100000.0 - 1.0) * 100.0
    dd = res.analyzers.dd.get_analysis()
    max_dd_pct = float(dd.get("max", {}).get("drawdown", 0.0))
    trades = res.analyzers.trades.get_analysis()
    total_closed = int(getattr(trades.total, "closed", 0)) if hasattr(trades, "total") else 0
    sharpe = 0.0
    if hasattr(res.analyzers, "sharpe"):
        try:
            sharpe = float(res.analyzers.sharpe.get_analysis().get("sharperatio", 0.0))
        except Exception:
            pass
    return {
        "name": name,
        "metrics": {
            "sharpe": round(sharpe, 6),
            "roi_pct": round(roi_pct, 6),
            "max_dd_pct": round(max_dd_pct, 6),
            "trades": total_closed
        }
    }
