# temporal_client.py
import asyncio, argparse
from temporalio.client import Client
from temporal_worker import BacktestWorkflow  # re-use definition

async def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--spec", required=True, help="Strategy JSON path")
    ap.add_argument("--period", default="30d")
    ap.add_argument("--refine-runs", type=int, default=6)
    ap.add_argument("--forward", action="store_true")
    ap.add_argument("--forward-cycles", type=int, default=6)
    ap.add_argument("--forward-refresh-secs", type=int, default=300)
    args = ap.parse_args()

    client = await Client.connect("localhost:7233")
    handle = await client.start_workflow(
        BacktestWorkflow.run,
        args.spec, args.period, args.refine_runs, args.forward, args.forward_cycles, args.forward_refresh_secs,
        id=f"bt-{args.spec.replace('\\','/').split('/')[-1]}",
        task_queue="bt-orchestrator",
    )
    print("Started workflow:", handle.id)
    # Wait and print result
    result = await handle.result()
    print(result)

if __name__ == "__main__":
    asyncio.run(main())
