﻿import os
import json
import pandas as pd
import numpy as np
import datetime

try:
    import yfinance as yf
except Exception:
    yf = None


def ensure_ohlcv(symbol, timeframe, period, auto_adjust=True):
    """Fetch OHLCV using yfinance and save to data/{symbol}_{timeframe}_{period}.csv
    Tries several ticker variants (symbol, symbol+'=X', symbol with '/' removed)
    and falls back to raising a clear error if none return data.
    """
    if yf is None:
        raise RuntimeError("yfinance not available in this environment")
    if not period:
        period = '30d'
    safe_symbol = str(symbol).replace('/', '_')
    outdir = os.path.join('data')
    os.makedirs(outdir, exist_ok=True)
    fname = f"{safe_symbol}_{timeframe}_{period}.csv"
    outpath = os.path.join(outdir, fname)

    # Candidate tickers to try, in order
    candidates = [str(symbol)]
    if not str(symbol).endswith("=X"):
        candidates.append(str(symbol) + "=X")
    # also try upper and slashed forms without separators
    candidates.append(str(symbol).replace("/", "").upper())
    candidates.append(str(symbol).replace("/", "").upper() + "=X")

    last_err = None
    for tick in candidates:
        try:
            df = yf.download(tick, period=period, interval=timeframe, progress=False, auto_adjust=auto_adjust)
            if df is None or df.empty:
                last_err = f"No data for {tick}"
                continue
            df.index = pd.to_datetime(df.index)
            df.rename(columns={
                'Open': 'open', 'High': 'high', 'Low': 'low', 'Close': 'close', 'Volume': 'volume'
            }, inplace=True)
            # keep canonical columns; if Volume missing handle gracefully
            cols = [c for c in ['open', 'high', 'low', 'close', 'volume'] if c in df.columns]
            df = df[cols]
            df.to_csv(outpath)
            return {'path': outpath, 'rows': len(df), 'symbol_used': tick}
        except Exception as e:
            last_err = repr(e)
            continue

    # If we reach here nothing worked
    raise RuntimeError(f"Failed to fetch OHLCV for {symbol}. Tried {candidates}. Last error: {last_err}")


def validate_csv(path):
    if not os.path.exists(path):
        return {'ok': False, 'error': 'file not found'}
    df = pd.read_csv(path)
    expected = set(['datetime', 'open', 'high', 'low', 'close', 'volume'])
    cols = set([c.lower() for c in df.columns])
    missing = expected - cols
    if missing:
        return {'ok': False, 'missing': list(missing)}
    return {'ok': True, 'rows': len(df)}


def _simple_ema_strategy(df, params):
    # coerce numeric columns for safety
    df = df.copy()
    for col in ['open','high','low','close','volume']:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors='coerce')
    # drop rows without close price
    if 'close' in df.columns:
        df = df.dropna(subset=['close'])

    fast = int(params.get('ema_fast', 10))
    slow = int(params.get('ema_slow', 20))
    df = df.copy()
    df['ema_fast'] = df['close'].ewm(span=fast, adjust=False).mean()
    df['ema_slow'] = df['close'].ewm(span=slow, adjust=False).mean()
    df['pos'] = np.where(df['ema_fast'] > df['ema_slow'], 1, 0)
    df['signal'] = df['pos'].diff()
    cash = 10000.0
    position = 0.0
    entry_price = 0.0
    trades = []
    equity = []
    eq = cash
    for i, row in df.iterrows():
        price = row['close']
        if row['signal'] == 1 and position == 0:
            position = eq / price
            entry_price = price
            eq = position * price
            trades.append({'type': 'buy', 'price': price, 'time': str(i)})
        elif row['signal'] == -1 and position > 0:
            pnl = position * price - position * entry_price
            cash = position * price
            trades.append({'type': 'sell', 'price': price, 'time': str(i), 'pnl': pnl})
            position = 0
            entry_price = 0
            eq = cash
        else:
            if position > 0:
                eq = position * price
            else:
                eq = cash
        equity.append(eq)
    if position > 0:
        last_price = df['close'].iloc[-1]
        pnl = position * last_price - position * entry_price
        trades.append({'type': 'sell', 'price': last_price, 'time': str(df.index[-1]), 'pnl': pnl})
        cash = position * last_price
        position = 0
        eq = cash
        if equity:
            equity[-1] = eq
    profits = [t['pnl'] for t in trades if 'pnl' in t and t['pnl'] > 0]
    losses = [t['pnl'] for t in trades if 'pnl' in t and t['pnl'] < 0]
    total_profit = sum(profits) if profits else 0.0
    total_loss = sum(losses) if losses else 0.0
    gross_loss = abs(total_loss)
    profit_factor = (total_profit / gross_loss) if gross_loss > 0 else float('inf')
    ntrades = len([t for t in trades if 'pnl' in t])
    wins = len([p for p in profits if p > 0])
    winrate = (wins / ntrades) if ntrades > 0 else 0.0
    expectancy = ((total_profit - gross_loss) / ntrades) if ntrades > 0 else 0.0
    peak = np.maximum.accumulate(equity) if equity else np.array([0])
    drawdowns = (peak - equity) / peak if len(peak) > 0 else np.array([0])
    max_dd = float(np.max(drawdowns)) * 100 if len(drawdowns) > 0 else 0.0
    total_return = (equity[-1] / equity[0] - 1) if len(equity) > 0 and equity[0] > 0 else 0.0
    rtot = total_return
    ravg = (total_return / ntrades) if ntrades > 0 else 0.0
    result = {
        'profit_factor': profit_factor,
        'expectancy': expectancy,
        'winrate': winrate,
        'rtot': rtot,
        'ravg': ravg,
        'max_drawdown_pct': max_dd,
        'ntrades': ntrades,
        'trades': trades
    }
    return result


def run_backtest_on_spec(spec_path):
    if not os.path.exists(spec_path):
        return {'ok': False, 'error': 'spec not found', 'path': spec_path}
    with open(spec_path, 'r', encoding='utf-8') as f:
        try:
            spec = json.load(f)
        except Exception as e:
            return {'ok': False, 'error': f'json load error: {e}'}
    symbol = spec.get('symbol', 'AUDCAD')
    timeframe = spec.get('timeframe', '5m')
    period = spec.get('period', '60d')
    data_res = ensure_ohlcv(symbol, timeframe, period)
    df = pd.read_csv(data_res['path'], index_col=0, parse_dates=True)
    # ensure 'close' exists and coerce to numeric
    if 'close' not in df.columns:
        return {'ok': False, 'error': 'data missing required columns', 'data_csv': data_res.get('path')}
    df['close'] = pd.to_numeric(df['close'], errors='coerce')
    df = df.dropna(subset=['close'])
    params = spec.get('strategy', {}).get('params', spec.get('params', {}))
    try:
        res = _simple_ema_strategy(df, params)
    except Exception as e:
        # return diagnostic info
        dtypes = {col: str(dtype) for col, dtype in df.dtypes.items()}
        head = df.head().to_dict()
        return {'ok': False, 'error': str(e), 'spec': spec_path, 'data_csv': data_res.get('path'), 'dtypes': dtypes, 'head': head}
    res['ok'] = True
    res['spec'] = spec_path
    res['data_csv'] = data_res['path']
    return res


def quick_refine(spec_path, max_runs=6):
    if not os.path.exists(spec_path):
        return {'ok': False, 'error': 'spec not found'}
    with open(spec_path, 'r', encoding='utf-8') as f:
        spec = json.load(f)
    opt = spec.get('optimization', {})
    params = opt.get('params', {})
    runs = []
    grids = {}
    for k, v in params.items():
        if isinstance(v, dict) and 'min' in v and 'max' in v and 'step' in v:
            grids[k] = list(range(v['min'], v['max'] + 1, v['step']))
        else:
            grids[k] = [v]
    import itertools
    keys = list(grids.keys())
    combos = list(itertools.product(*(grids[k] for k in keys)))
    combos = combos[:max_runs]
    for combo in combos:
        p = dict(zip(keys, combo))
        tname = spec_path + '.run.' + '_'.join([f"{k}{v}" for k, v in p.items()]) + '.json'
        spec2 = dict(spec)
        if 'strategy' not in spec2:
            spec2['strategy'] = {}
        spec2['strategy']['params'] = p
        with open(tname, 'w', encoding='utf-8') as fo:
            json.dump(spec2, fo)
        res = run_backtest_on_spec(tname)
        res['run_params'] = p
        runs.append(res)
    return {'ok': True, 'runs': runs}


def select_best(results_json, primary='profit_factor'):
    if isinstance(results_json, str):
        try:
            data = json.loads(results_json)
        except Exception:
            if os.path.exists(results_json):
                with open(results_json, 'r', encoding='utf-8') as f:
                    data = json.load(f)
            else:
                return {'ok': False, 'error': 'invalid input to select_best'}
    else:
        data = results_json
    runs = data.get('runs', [])
    if not runs:
        return {'ok': False, 'error': 'no runs'}
    best = None
    best_val = None
    for r in runs:
        val = r.get(primary, None)
        if val is None:
            val = r.get('result', {}).get(primary) if isinstance(r.get('result'), dict) else None
        if val is None:
            continue
        try:
            valf = float(val)
        except Exception:
            continue
        if best is None or valf > best_val:
            best = r
            best_val = valf
    return {'ok': True, 'best': best}
# --- Minimal builder for the console agent ---

import shlex
from types import SimpleNamespace

def build_main_agent(cfg):
    """
    Returns a simple agent object with:
      - .tools (for !!tools)
      - .run(text) that understands a few console commands
    Commands:
      bt|backtest <spec.json>
      refine <spec.json>
      best|select_best <results.json-or-string>
      ohlcv <symbol> <timeframe> <period>
    """
    class _ConsoleAgent:
        def __init__(self, cfg):
            self.cfg = cfg
            self.tools = [
                SimpleNamespace(name="backtest"),
                SimpleNamespace(name="refine"),
                SimpleNamespace(name="select_best"),
                SimpleNamespace(name="ohlcv"),
            ]

        def run(self, text: str):
            """
            Parse and execute a single console command. Supports both trading
            commands (backtest, refine, select_best, ohlcv) and a few utility
            commands ("!!tools", "!!reload", "!shell", "!py"). Returns a
            string that should be printed by the caller.
            """
            # Normalize to a stripped string to simplify checks
            text = (text or "").strip()
            if not text:
                return "Say: backtest <spec.json> | refine <spec.json> | select_best <json> | ohlcv <sym> <tf> <period>"

            # --- Utility commands ---
            # List available commands (trading ops + utilities)
            if text in ("!!tools", "tools"):
                return ("Commands:\n"
                        "  backtest <spec.json>\n"
                        "  refine <spec.json>\n"
                        "  select_best <results.json-or-string>\n"
                        "  ohlcv <symbol> <timeframe> <period>\n"
                        "Utilities:\n"
                        "  !!reload\n"
                        "  !py <code>\n"
                        "  !shell <cmd>")

            # Reload hint. In this simple console agent we can't really
            # hot‑reload core code safely, so advise a restart.
            if text in ("!!reload", "reload"):
                return "[reload] Use Ctrl+C then re-run main_agent_entry.py"

            # Execute a shell command
            if text.startswith("!shell"):
                import subprocess
                cmd = text.partition("!shell")[2].strip()
                if not cmd:
                    return "Usage: !shell <command>"
                try:
                    out = subprocess.run(cmd, shell=True, capture_output=True, text=True)
                    return (out.stdout or "") + (out.stderr or "")
                except Exception as e:
                    return f"shell error: {e}"

            # Execute inline Python code
            if text.startswith("!py"):
                code = text.partition("!py")[2]
                # Provide only core functions in a limited namespace
                ns = {}
                ns["ensure_ohlcv"] = ensure_ohlcv
                ns["run_backtest_on_spec"] = run_backtest_on_spec
                ns["quick_refine"] = quick_refine
                ns["select_best"] = select_best
                try:
                    exec(code, ns, ns)
                    return "[py done]"
                except Exception as e:
                    import traceback
                    traceback.print_exc()
                    return f"[py error] {e}"

            # --- Trading commands ---
            try:
                args = shlex.split(text)
            except Exception:
                args = text.split()

            if not args:
                return "Say: backtest <spec.json> | refine <spec.json> | select_best <json> | ohlcv <sym> <tf> <period>"

            cmd = args[0].lower()

            if cmd in ("bt", "backtest"):
                if len(args) < 2:
                    return "usage: backtest <spec.json>"
                res = run_backtest_on_spec(args[1])
                return json.dumps(res, indent=2)

            if cmd == "refine":
                if len(args) < 2:
                    return "usage: refine <spec.json>"
                res = quick_refine(args[1])
                return json.dumps(res, indent=2)

            if cmd in ("best", "select_best"):
                if len(args) < 2:
                    return "usage: select_best <results.json-or-string>"
                res = select_best(args[1])
                return json.dumps(res, indent=2)

            if cmd == "ohlcv":
                if len(args) < 4:
                    return "usage: ohlcv <symbol> <timeframe> <period>   e.g. ohlcv SPY 1d 60d"
                sym, tf, period = args[1], args[2], args[3]
                res = ensure_ohlcv(sym, tf, period)
                return json.dumps(res, indent=2)

            return f"Unknown command: {cmd}"

        # Add run_cmd for compatibility with console REPLs
        # This delegates to run() and prints any non-empty output.
        def run_cmd(self, text: str):
            out = self.run(text)
            if out:
                try:
                    print(out)
                except Exception:
                    # fallback if printing fails
                    print(out)
            return out

    return _ConsoleAgent(cfg)

